# Pixel Dice — راهنمای ساخت APK

## راه ۱: ساخت خودکار روی GitHub (بدون نصب هیچ برنامه‌ای)
1. توی github.com یه حساب بساز (یا وارد شو) و یه Repository جدید بساز (اسمش مثلاً PixelDice).
2. روی «uploading an existing file» بزن و **محتوای** این پوشه (نه خود zip) رو بکش داخلش.
   پوشه‌ی `.github` هم باید آپلود بشه (اگه مرورگر پوشه‌های مخفی رو نشون نمیده، از گوشی/کامپیوتر گزینه‌ی نمایش فایل‌های مخفی رو بزن).
3. Commit changes.
4. بالای صفحه تب **Actions** → «Build APK» → صبر کن تا تیک سبز بخوره (حدود ۳ تا ۵ دقیقه).
5. روی همون اجرا بزن، پایین صفحه توی بخش **Artifacts** فایل `PixelDice-APK` رو دانلود کن. داخلش `PixelDice.apk` هست.

## راه ۲: Android Studio
File → Open → همین پوشه. بعد از Sync: Build → Build Bundle(s) / APK(s) → Build APK(s) با نوع release.
فایل: `app/build/outputs/apk/release/PixelDice.apk`

## نصب روی گوشی (شیائومی و بقیه)
فایل PixelDice.apk رو بفرست گوشی، روش بزن، اگه پرسید «نصب از منبع ناشناس» اجازه بده، بعد «نصب».
