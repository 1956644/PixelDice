/* Pixel Dice - gfx.js : low-res canvas, pixel fonts, dice skins, billiard table, UI widgets
 * Credit: Hirkan
 */
(function () {
  'use strict';
  var G = window.G = {};
  var cv = document.getElementById('c');
  var ctx = cv.getContext('2d');
  var W = 180, H = 360, K = 3, DPR = 1;
  G.cv = cv; G.ctx = ctx; G.S = 2;       // canvas is drawn at 2x so Persian text stays sharp; art still uses 1 logical px = 1 big pixel

  /* ------------------------------------------------------------ palette */
  var P = G.P = {
    ink: '#241608', wood0: '#2a1408', wood1: '#4b2c14', wood2: '#6b3f1c', wood3: '#8d5a2b',
    gold0: '#7a5a10', gold1: '#c8962a', gold2: '#f0c040', gold3: '#fff0a8',
    felt0: '#0e5a2c', felt1: '#137a3e', felt2: '#1a9150', felt3: '#2aa862',
    cream: '#f6ead0', parch: '#f1e2bb', parch2: '#d9c28f', parch3: '#b89a60',
    red: '#d6344a', redD: '#8c1426', green: '#3fbf6a', greenD: '#1c7a3a', blue: '#4aa3ff', white: '#ffffff', black: '#000000'
  };

  function rng(seed) { var x = seed >>> 0; return function () { x = (x + 0x6D2B79F5) >>> 0; var t = x; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  G.rng = rng;
  function hexRgb(h) { var n = parseInt(h.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
  G.fa = function (n) { return String(n).replace(/\d/g, function (d) { return '۰۱۲۳۴۵۶۷۸۹'.charAt(d); }); };

  /* ------------------------------------------------------------- canvas */
  G.resize = function () {
    DPR = window.devicePixelRatio || 1;
    var devW = Math.max(200, Math.round(window.innerWidth * DPR));
    var devH = Math.max(300, Math.round(window.innerHeight * DPR));
    K = Math.max(2, Math.round(devW / 180));
    W = Math.ceil(devW / K); H = Math.ceil(devH / K);
    cv.width = W * G.S; cv.height = H * G.S;
    cv.style.width = (W * K / DPR) + 'px';
    cv.style.height = (H * K / DPR) + 'px';
    ctx.setTransform(G.S, 0, 0, G.S, 0, 0);
    ctx.imageSmoothingEnabled = false;
    G.W = W; G.H = H; G.K = K; G.DPR = DPR;
    tableCache = null;
    if (G.onResize) G.onResize();
  };
  G.toLogical = function (e) { return { x: Math.floor(e.clientX * DPR / K), y: Math.floor(e.clientY * DPR / K) }; };

  /* -------------------------------------------------------- bitmap font */
  var GL = {
    'A': '01110 10001 10001 11111 10001 10001 10001', 'B': '11110 10001 10001 11110 10001 10001 11110',
    'C': '01110 10001 10000 10000 10000 10001 01110', 'D': '11100 10010 10001 10001 10001 10010 11100',
    'E': '11111 10000 10000 11110 10000 10000 11111', 'F': '11111 10000 10000 11110 10000 10000 10000',
    'G': '01110 10001 10000 10111 10001 10001 01111', 'H': '10001 10001 10001 11111 10001 10001 10001',
    'I': '01110 00100 00100 00100 00100 00100 01110', 'J': '00111 00010 00010 00010 00010 10010 01100',
    'K': '10001 10010 10100 11000 10100 10010 10001', 'L': '10000 10000 10000 10000 10000 10000 11111',
    'M': '10001 11011 10101 10101 10001 10001 10001', 'N': '10001 11001 10101 10011 10001 10001 10001',
    'O': '01110 10001 10001 10001 10001 10001 01110', 'P': '11110 10001 10001 11110 10000 10000 10000',
    'Q': '01110 10001 10001 10001 10101 10010 01101', 'R': '11110 10001 10001 11110 10100 10010 10001',
    'S': '01111 10000 10000 01110 00001 00001 11110', 'T': '11111 00100 00100 00100 00100 00100 00100',
    'U': '10001 10001 10001 10001 10001 10001 01110', 'V': '10001 10001 10001 10001 10001 01010 00100',
    'W': '10001 10001 10001 10101 10101 11011 10001', 'X': '10001 10001 01010 00100 01010 10001 10001',
    'Y': '10001 10001 01010 00100 00100 00100 00100', 'Z': '11111 00001 00010 00100 01000 10000 11111',
    '0': '01110 10001 10011 10101 11001 10001 01110', '1': '00100 01100 00100 00100 00100 00100 01110',
    '2': '01110 10001 00001 00010 00100 01000 11111', '3': '11110 00001 00001 01110 00001 00001 11110',
    '4': '00010 00110 01010 10010 11111 00010 00010', '5': '11111 10000 11110 00001 00001 10001 01110',
    '6': '00110 01000 10000 11110 10001 10001 01110', '7': '11111 00001 00010 00100 01000 01000 01000',
    '8': '01110 10001 10001 01110 10001 10001 01110', '9': '01110 10001 10001 01111 00001 00010 01100',
    ':': '00000 00100 00100 00000 00100 00100 00000', '.': '00000 00000 00000 00000 00000 01100 01100',
    ',': '00000 00000 00000 00000 01100 00100 01000', '-': '00000 00000 00000 11111 00000 00000 00000',
    '+': '00000 00100 00100 11111 00100 00100 00000', '/': '00001 00010 00010 00100 01000 01000 10000',
    '!': '00100 00100 00100 00100 00100 00000 00100', '?': '01110 10001 00001 00010 00100 00000 00100',
    '(': '00010 00100 01000 01000 01000 00100 00010', ')': '01000 00100 00010 00010 00010 00100 01000',
    "'": '00100 00100 01000 00000 00000 00000 00000', '=': '00000 00000 11111 00000 11111 00000 00000',
    '%': '11001 11010 00010 00100 01000 01011 10011', '*': '00000 10101 01110 11111 01110 10101 00000',
    '#': '01010 01010 11111 01010 11111 01010 01010', '>': '01000 00100 00010 00001 00010 00100 01000',
    '<': '00010 00100 01000 10000 01000 00100 00010', '_': '00000 00000 00000 00000 00000 00000 11111',
    '[': '01110 01000 01000 01000 01000 01000 01110', ']': '01110 00010 00010 00010 00010 00010 01110',
    '|': '00100 00100 00100 00100 00100 00100 00100', '&': '01100 10010 10100 01000 10101 10010 01101',
    '@': '01110 10001 10111 10101 10111 10000 01110', '"': '01010 01010 00000 00000 00000 00000 00000',
    'a': '00000 00000 01110 00001 01111 10001 01111', 'b': '10000 10000 11110 10001 10001 10001 11110',
    'c': '00000 00000 01110 10000 10000 10001 01110', 'd': '00001 00001 01111 10001 10001 10001 01111',
    'e': '00000 00000 01110 10001 11111 10000 01110', 'f': '00110 01001 01000 11100 01000 01000 01000',
    'g': '00000 01111 10001 10001 01111 00001 01110', 'h': '10000 10000 10110 11001 10001 10001 10001',
    'i': '00100 00000 01100 00100 00100 00100 01110', 'j': '00010 00000 00110 00010 00010 10010 01100',
    'k': '10000 10000 10010 10100 11000 10100 10010', 'l': '01100 00100 00100 00100 00100 00100 01110',
    'm': '00000 00000 11010 10101 10101 10101 10101', 'n': '00000 00000 10110 11001 10001 10001 10001',
    'o': '00000 00000 01110 10001 10001 10001 01110', 'p': '00000 00000 11110 10001 11110 10000 10000',
    'q': '00000 00000 01111 10001 01111 00001 00001', 'r': '00000 00000 10110 11001 10000 10000 10000',
    's': '00000 00000 01110 10000 01110 00001 11110', 't': '01000 01000 11100 01000 01000 01001 00110',
    'u': '00000 00000 10001 10001 10001 10011 01101', 'v': '00000 00000 10001 10001 10001 01010 00100',
    'w': '00000 00000 10001 10001 10101 10101 01010', 'x': '00000 00000 10001 01010 00100 01010 10001',
    'y': '00000 00000 10001 10001 01111 00001 01110', 'z': '00000 00000 11111 00010 00100 01000 11111',
    ' ': '00000 00000 00000 00000 00000 00000 00000'
  };
  var GB = {};
  Object.keys(GL).forEach(function (ch) { GB[ch] = GL[ch].split(' '); });

  var cache = {};
  function mkCanvas(w, h) { var c = document.createElement('canvas'); c.width = Math.max(1, w); c.height = Math.max(1, h); return c; }

  function mkHi(w, h) {
    var c = mkCanvas(Math.round(w * G.S), Math.round(h * G.S)), x = c.getContext('2d');
    x.scale(G.S, G.S); x.imageSmoothingEnabled = false; c._h = h; c._w = w; return c;
  }
  G.mkHi = mkHi;

  function bmpCanvas(str, scale, color) {
    var key = 'b|' + scale + '|' + color + '|' + str;
    if (cache[key]) return cache[key];
    var s = str, n = s.length;
    var c = mkCanvas(Math.max(1, (n * 6 - 1) * scale), 7 * scale), g = c.getContext('2d');
    g.fillStyle = color;
    for (var i = 0; i < n; i++) {
      var rows = GB[s.charAt(i)] || GB['?'];
      for (var r = 0; r < 7; r++) for (var q = 0; q < 5; q++)
        if (rows[r].charAt(q) === '1') g.fillRect((i * 6 + q) * scale, r * scale, scale, scale);
    }
    cache[key] = c;
    return c;
  }

  var SYS_FONT = '"Vazirmatn","Noto Naskh Arabic","Noto Sans Arabic","Segoe UI","Tahoma","Arial",sans-serif';
  var mctx = mkCanvas(4, 4).getContext('2d');
  function sysFont(size, bold) { return (bold ? 'bold ' : '') + size + 'px ' + SYS_FONT; }
  function isRtl(str) { return /[֐-ࣿﭐ-﻿]/.test(str); }
  function sysWidth(str, size, bold) {
    mctx.font = sysFont(size, bold); mctx.direction = isRtl(str) ? 'rtl' : 'ltr';
    return Math.ceil(mctx.measureText(str).width);
  }
  function sysCanvas(str, size, color, bold) {
    var key = 's|' + size + '|' + (bold ? 1 : 0) + '|' + color + '|' + str;
    if (cache[key]) return cache[key];
    var w = sysWidth(str, size, bold) + 2, h = Math.ceil(size * 1.5);
    var c = mkCanvas(w, h), g = c.getContext('2d', { willReadFrequently: true });
    g.font = sysFont(size, bold); g.direction = isRtl(str) ? 'rtl' : 'ltr';
    g.textAlign = 'left'; g.textBaseline = 'alphabetic'; g.fillStyle = '#fff';
    g.fillText(str, 1, Math.round(size * 1.08));
    var id = g.getImageData(0, 0, c.width, c.height), d = id.data, rgb = hexRgb(color);
    for (var i = 0; i < d.length; i += 4) {
      if (d[i + 3] >= 112) { d[i] = rgb[0]; d[i + 1] = rgb[1]; d[i + 2] = rgb[2]; d[i + 3] = 255; } else d[i + 3] = 0;
    }
    g.putImageData(id, 0, 0);
    cache[key] = c;
    return c;
  }
  G.clearTextCache = function () { cache = {}; };

  function isBmp(str, o) { return !(o && o.sys) && /^[\x20-\x7E]*$/.test(str); }
  // text(str, x, y, {c:color, s:scale, size:px, a:'l'|'c'|'r', sh:shadowColor, bold, sys}, g)
  G.text = function (str, x, y, o, g) {
    o = o || {}; g = g || ctx; str = String(str);
    var col = o.c || '#ffffff', cnv, dx;
    if (isBmp(str, o)) {
      cnv = bmpCanvas(str, o.s || 1, col);
      var w = cnv.width;
      dx = Math.round(o.a === 'c' ? x - Math.floor(w / 2) : (o.a === 'r' ? x - w : x)); y = Math.round(y);
      if (o.sh) g.drawImage(bmpCanvas(str, o.s || 1, o.sh), dx + (o.s || 1), y + (o.s || 1));
      g.drawImage(cnv, dx, y);
      return w;
    }
    var size = o.size || 9, tw = sysWidth(str, size, o.bold), S = G.S;
    dx = o.a === 'c' ? x - tw / 2 : (o.a === 'r' ? x - tw : x);
    dx = Math.round(dx * S) / S + 1; y = Math.round(y * S) / S;
    g.font = sysFont(size, o.bold); g.direction = isRtl(str) ? 'rtl' : 'ltr';
    g.textAlign = 'left'; g.textBaseline = 'alphabetic';
    var by = y + size * 1.08;
    if (o.sh) { g.fillStyle = o.sh; g.fillText(str, dx + 1, by + 1); }
    g.fillStyle = col; g.fillText(str, dx, by);
    return tw;
  };
  G.textW = function (str, o) {
    o = o || {}; str = String(str);
    return isBmp(str, o) ? Math.max(0, str.length * 6 - 1) * (o.s || 1) : sysWidth(str, o.size || 9, o.bold) + 2;
  };
  // fit a name to a pixel width (adds '.' when cut)
  G.fit = function (str, maxW, o) {
    str = String(str);
    if (G.textW(str, o) <= maxW) return str;
    while (str.length > 1 && G.textW(str + '.', o) > maxW) str = str.slice(0, -1);
    return str + '.';
  };
  // word-wrap for RTL (or any) text, returns lines in reading order
  G.wrap = function (str, size, maxW, bold) {
    var words = String(str).split(/\s+/), lines = [], cur = '', i, t;
    for (i = 0; i < words.length; i++) {
      t = cur ? cur + ' ' + words[i] : words[i];
      if (sysWidth(t, size, bold) <= maxW || !cur) cur = t; else { lines.push(cur); cur = words[i]; }
    }
    if (cur) lines.push(cur);
    return lines;
  };

  /* ------------------------------------------------------------ sprites */
  var SP = {
    pencil: { rows: ['.....kk.', '....kyyk', '...kyyk.', '..kyyk..', '.kyyk...', 'kppk....', 'kpk.....', 'kk......'], pal: { k: '#241608', y: '#f0c040', p: '#ff9aa8' } },
    star: { rows: ['...y...', '..yyy..', 'yyyyyyy', '.yyyyy.', '..yyy..', '.yy.yy.', 'yy...yy'], pal: { y: '#f0c040' } },
    starOff: { rows: ['...y...', '..yyy..', 'yyyyyyy', '.yyyyy.', '..yyy..', '.yy.yy.', 'yy...yy'], pal: { y: '#5a3a1a' } },
    lock: { rows: ['..kkk..', '.k...k.', '.k...k.', 'kkkkkkk', 'kyyyyyk', 'kyykyyk', 'kyykyyk', 'kkkkkkk'], pal: { k: '#241608', y: '#c8962a' } },
    check: { rows: ['......g', '.....gg', 'g...gg.', 'gg.gg..', '.ggg...', '..g....'], pal: { g: '#4cff8a' } },
    cross: { rows: ['r...r', '.r.r.', '..r..', '.r.r.', 'r...r'], pal: { r: '#ff5a6e' } },
    down: { rows: ['yyyyyyy', '.yyyyy.', '..yyy..', '...y...'], pal: { y: '#f0c040' } },
    left: { rows: ['...w', '..ww', '.www', 'wwww', '.www', '..ww', '...w'], pal: { w: '#f6ead0' } },
    wifi: { rows: ['..wwwww..', '.w.....w.', 'w..www..w', '..w...w..', '....w....'], pal: { w: '#ffffff' } },
    spk: { rows: ['..w....', '.ww..w.', 'www...w', 'www.w.w', 'www...w', '.ww..w.', '..w....'], pal: { w: '#f6ead0' } },
    spkOff: { rows: ['..w....', '.ww.r.r', 'www..r.', 'www.r.r', 'www....', '.ww....', '..w....'], pal: { w: '#f6ead0', r: '#ff5a6e' } },
    cup: { rows: ['yyyyyyyyy', 'yyyyyyyyy', 'yyyyyyyyy', '.yyyyyyy.', '..yyyyy..', '...yyy...', '....y....', '...yyy...', '..yyyyy..'], pal: { y: '#f0c040' } }
  };
  G.sprite = function (name, x, y, scale, g) {
    g = g || ctx; scale = scale || 1;
    var s = SP[name], r, q, ch;
    for (r = 0; r < s.rows.length; r++) for (q = 0; q < s.rows[r].length; q++) {
      ch = s.rows[r].charAt(q);
      if (ch !== '.') { g.fillStyle = s.pal[ch]; g.fillRect(Math.round(x) + q * scale, Math.round(y) + r * scale, scale, scale); }
    }
    return { w: s.rows[0].length * scale, h: s.rows.length * scale };
  };

  function rect(g, x, y, w, h, col) { g.fillStyle = col; g.fillRect(x, y, w, h); }
  G.rect = function (x, y, w, h, col, g) { rect(g || ctx, x, y, w, h, col); };

  /* -------------------------------------------------------------- skins */
  var SKINS = G.SKINS = [
    { name: 'IVORY', body: '#f4ecd6', hi: '#ffffff', lo: '#cdbf9c', edge: '#2a1a0c', pip: '#2a1a0c' },
    { name: 'RUBY', body: '#d02a3e', hi: '#ff7f8e', lo: '#8c1426', edge: '#3a0610', pip: '#fff2f2' },
    { name: 'EMERALD', body: '#2fb36d', hi: '#8ef0b8', lo: '#16723f', edge: '#06301a', pip: '#eafff2' },
    { name: 'GOLD', body: '#f0c040', hi: '#fff2a8', lo: '#b0841a', edge: '#4a3206', pip: '#5a3a06', fx: 'shine' },
    { name: 'ICE', body: '#a8e6ff', hi: '#f0fbff', lo: '#5fb4dc', edge: '#10405c', pip: '#0f3f66', fx: 'sparkle' },
    { name: 'GALAXY', body: '#2a1a5e', hi: '#5b43b0', lo: '#150b36', edge: '#0a0420', pip: '#7ff0ff', fx: 'stars' },
    { name: 'LAVA', body: '#e5532a', hi: '#ffb347', lo: '#8a1f0c', edge: '#2a0a04', pip: '#fff0a0', fx: 'ember' },
    { name: 'RAINBOW', body: '#ff66aa', hi: '#ffd0e6', lo: '#aa2266', edge: '#240a1a', pip: '#ffffff', fx: 'rainbow' }
  ];
  var PIPS = { 1: [4], 2: [0, 8], 3: [0, 4, 8], 4: [0, 2, 6, 8], 5: [0, 2, 4, 6, 8], 6: [0, 3, 6, 2, 5, 8] };

  // draw one die. o: {idx, gold, dim, flat, t}
  G.die = function (x, y, w, h, val, skinId, t, o, g) {
    g = g || ctx; o = o || {};
    x = Math.round(x); y = Math.round(y); w = Math.round(w); h = Math.round(h);
    var sk = SKINS[skinId] || SKINS[0], body = sk.body, hi = sk.hi, lo = sk.lo, edge = sk.edge, pip = sk.pip;
    if (!o.flat) { rect(g, x + 2, y + h, w - 3, 2, 'rgba(0,0,0,0.38)'); }
    if (val === 0) {                                // empty slot (not thrown yet)
      g.fillStyle = 'rgba(0,0,0,0.22)'; g.fillRect(x + 1, y + 1, w - 2, h - 2);
      g.fillStyle = 'rgba(255,255,255,0.25)';
      for (var k = 2; k < w - 2; k += 4) { g.fillRect(x + k, y, 2, 1); g.fillRect(x + k, y + h - 1, 2, 1); }
      for (k = 2; k < h - 2; k += 4) { g.fillRect(x, y + k, 1, 2); g.fillRect(x + w - 1, y + k, 1, 2); }
      return;
    }
    if (sk.fx === 'rainbow') {
      var hue = Math.floor(((t || 0) * 0.08 + (o.idx || 0) * 55) % 360);
      body = 'hsl(' + hue + ',85%,58%)'; hi = 'hsl(' + hue + ',95%,82%)'; lo = 'hsl(' + hue + ',70%,36%)';
    }
    rect(g, x + 1, y, w - 2, h, edge); rect(g, x, y + 1, w, h - 2, edge);
    rect(g, x + 1, y + 1, w - 2, h - 2, body);
    rect(g, x + 2, y + 1, w - 4, 1, hi); rect(g, x + 1, y + 2, 1, h - 4, hi);
    rect(g, x + 2, y + h - 2, w - 4, 1, lo); rect(g, x + w - 2, y + 2, 1, h - 4, lo);
    rect(g, x + 2, y + h - 3, w - 4, 1, lo);
    // fx under pips
    var tt = t || 0, i, r;
    if (sk.fx === 'shine') {
      var kk = Math.floor(tt / 35) % (w + h + 24) - 12;
      for (r = 2; r < h - 2; r++) { var px = kk - r; if (px >= 2 && px < w - 3) rect(g, x + px, y + r, 2, 1, '#fffbd0'); }
    } else if (sk.fx === 'stars') {
      var rs = rng(91 + (o.idx || 0));
      for (i = 0; i < 7; i++) { var sx = 2 + Math.floor(rs() * (w - 4)), sy = 2 + Math.floor(rs() * (h - 4)); if (((tt / 300 + i * 1.7) | 0) % 3 !== 0) rect(g, x + sx, y + sy, 1, 1, i % 2 ? '#ffffff' : '#9fdcff'); }
    } else if (sk.fx === 'ember') {
      for (i = 0; i < 5; i++) { var ey = h - 3 - Math.floor(((tt / 70) + i * 9) % (h - 4)); var ex = 3 + ((i * 7 + (o.idx || 0) * 3) % (w - 6)); rect(g, x + ex, y + ey, 1, 1, i % 2 ? '#ffd24a' : '#ff8a2a'); }
    }
    // pips
    var ps = Math.max(2, Math.round(Math.min(w, h) * 0.17)), pat = PIPS[val] || [], cols = [0.27, 0.5, 0.73];
    for (i = 0; i < pat.length; i++) {
      var cx = x + Math.round(w * cols[pat[i] % 3]) - (ps >> 1), cy = y + Math.round(h * cols[(pat[i] / 3) | 0]) - (ps >> 1);
      rect(g, cx, cy, ps, ps, pip);
      rect(g, cx + ps - 1, cy + 1, 1, ps - 1, 'rgba(0,0,0,0.28)'); rect(g, cx + 1, cy + ps - 1, ps - 1, 1, 'rgba(0,0,0,0.28)');
    }
    if (sk.fx === 'sparkle') {
      var tw = (((tt / 260) | 0) + (o.idx || 0)) % 6;
      var spx = [[3, 3], [w - 5, 4], [4, h - 5], [w - 4, h - 4], [(w >> 1), 3], [3, (h >> 1)]][tw];
      rect(g, x + spx[0], y + spx[1], 1, 1, '#ffffff'); rect(g, x + spx[0] - 1, y + spx[1], 3, 1, 'rgba(255,255,255,0.8)'); rect(g, x + spx[0], y + spx[1] - 1, 1, 3, 'rgba(255,255,255,0.8)');
    }
    if (o.gold) {                                    // selected = counted
      g.fillStyle = P.gold2;
      g.fillRect(x - 1, y - 1, w + 2, 1); g.fillRect(x - 1, y + h, w + 2, 1); g.fillRect(x - 1, y, 1, h); g.fillRect(x + w, y, 1, h);
    }
    if (o.dim) {                                     // not selected = will be thrown again
      g.fillStyle = 'rgba(20,10,0,0.5)';
      for (var yy = 0; yy < h; yy++) for (var xx = (yy % 2); xx < w; xx += 2) g.fillRect(x + xx, y + yy, 1, 1);
    }
  };

  /* -------------------------------------------------------------- table */
  var tableCache = null;
  G.TR = 11;                                  // rail thickness
  var BAYER = [[0, 8, 2, 10], [12, 4, 14, 6], [3, 11, 1, 9], [15, 7, 13, 5]];

  function pocket(g, cx, cy, r) {
    var dx, dy, d;
    for (dy = -r - 3; dy <= r + 3; dy++) for (dx = -r - 3; dx <= r + 3; dx++) {
      d = Math.sqrt(dx * dx + dy * dy);
      if (d <= r) g.fillStyle = (dx + dy < -r * 0.8 && d > r - 2.2) ? '#1c120a' : '#050302';
      else if (d <= r + 1.2) g.fillStyle = '#3a2210';
      else if (d <= r + 2.3) g.fillStyle = '#7a4a22';
      else if (d <= r + 3.2) g.fillStyle = P.gold1;
      else continue;
      g.fillRect(cx + dx, cy + dy, 1, 1);
    }
  }
  function diamond(g, cx, cy, col, col2) {
    rect(g, cx, cy - 2, 1, 5, col); rect(g, cx - 1, cy - 1, 3, 3, col); rect(g, cx - 2, cy, 5, 1, col);
    rect(g, cx, cy, 1, 1, col2 || P.gold3);
  }
  function gem(g, cx, cy, col) { rect(g, cx - 1, cy - 1, 3, 3, col); rect(g, cx - 1, cy - 1, 1, 1, '#ffffff'); }

  function buildTable() {
    var R = G.TR, CU = 3, c = mkCanvas(W, H), g = c.getContext('2d'), rnd = rng(11), i;
    g.imageSmoothingEnabled = false;
    rect(g, 0, 0, W, H, P.wood1);
    for (i = 0; i < 700; i++) {                                    // wood grain on the rails
      var side = (rnd() * 4) | 0, len = 6 + ((rnd() * 18) | 0), col = rnd() < 0.5 ? P.wood2 : P.wood0, gx, gy;
      if (side === 0) { gx = (rnd() * W) | 0; gy = (rnd() * R) | 0; rect(g, gx, gy, len, 1, col); }
      else if (side === 1) { gx = (rnd() * W) | 0; gy = H - 1 - ((rnd() * R) | 0); rect(g, gx, gy, len, 1, col); }
      else if (side === 2) { gx = (rnd() * R) | 0; gy = (rnd() * H) | 0; rect(g, gx, gy, 1, len, col); }
      else { gx = W - 1 - ((rnd() * R) | 0); gy = (rnd() * H) | 0; rect(g, gx, gy, 1, len, col); }
    }
    // outer bevel
    rect(g, 0, 0, W, 1, P.wood0); rect(g, 0, H - 1, W, 1, P.wood0); rect(g, 0, 0, 1, H, P.wood0); rect(g, W - 1, 0, 1, H, P.wood0);
    rect(g, 1, 1, W - 2, 1, P.wood3); rect(g, 1, 1, 1, H - 2, P.wood3);
    // gold inlay + groove
    g.strokeStyle = P.gold1; g.lineWidth = 1; g.strokeRect(R - 3.5, R - 3.5, W - 2 * R + 7, H - 2 * R + 7);
    g.strokeStyle = P.wood0; g.strokeRect(R - 1.5, R - 1.5, W - 2 * R + 3, H - 2 * R + 3);
    // cushion
    rect(g, R, R, W - 2 * R, H - 2 * R, P.felt0);
    rect(g, R, R, W - 2 * R, 1, P.felt1); rect(g, R, R, 1, H - 2 * R, P.felt1);
    // felt with a dithered vignette
    var fx = R + CU, fy = R + CU, fw = W - 2 * fx, fh = H - 2 * fy;
    var id = g.createImageData(fw, fh), d = id.data, lv = [hexRgb(P.felt0), hexRgb(P.felt1), hexRgb(P.felt2), hexRgb(P.felt3)];
    var cx = fw / 2, cy = fh * 0.5, x, y, dd, v, l, p;
    for (y = 0; y < fh; y++) for (x = 0; x < fw; x++) {
      var nx = (x - cx) / (fw / 2), ny = (y - cy) / (fh / 2);
      dd = Math.min(1.2, Math.sqrt(nx * nx * 0.9 + ny * ny * 0.7));
      v = 0.55 + 2.05 * Math.pow(1 - Math.min(1, dd), 1.15);
      l = Math.floor(v + BAYER[y & 3][x & 3] / 16); l = l < 0 ? 0 : (l > 3 ? 3 : l);
      p = (y * fw + x) * 4; d[p] = lv[l][0]; d[p + 1] = lv[l][1]; d[p + 2] = lv[l][2]; d[p + 3] = 255;
    }
    g.putImageData(id, fx, fy);
    // soft lattice on the felt
    g.fillStyle = 'rgba(255,255,255,0.045)';
    for (y = fy; y < fy + fh; y++) for (x = fx + ((y * 1) % 14); x < fx + fw; x += 14) g.fillRect(x, y, 1, 1);
    for (y = fy; y < fy + fh; y++) for (x = fx + (13 - (y % 14)); x < fx + fw; x += 14) g.fillRect(x, y, 1, 1);
    // magic ring around the dice area
    var ccx = W >> 1, ccy = G.diceCY || Math.round(H * 0.5), rr = 50, a;
    for (a = 0; a < 360; a += 3) {
      var rx = Math.round(ccx + Math.cos(a * Math.PI / 180) * rr), ry = Math.round(ccy + Math.sin(a * Math.PI / 180) * rr * 0.62);
      g.fillStyle = (a % 30 === 0) ? 'rgba(240,192,64,0.8)' : 'rgba(255,255,255,0.16)';
      g.fillRect(rx, ry, 1, 1);
    }
    [0, 90, 180, 270].forEach(function (aa) { diamond(g, Math.round(ccx + Math.cos(aa * Math.PI / 180) * rr), Math.round(ccy + Math.sin(aa * Math.PI / 180) * rr * 0.62), P.gold2); });
    // rail ornaments
    var gx2, k;
    for (k = 1; k <= 5; k++) { gx2 = Math.round(W * k / 6); if (k === 3) { gem(g, gx2, 5, '#4aa3ff'); gem(g, gx2, H - 6, '#ff5a6e'); } else { diamond(g, gx2, 5, P.gold2); diamond(g, gx2, H - 6, P.gold2); } }
    for (k = 1; k <= 7; k++) { var gy2 = Math.round(H * k / 8); if (k === 4) continue; if (k % 3 === 0) { gem(g, 5, gy2, '#4cff8a'); gem(g, W - 6, gy2, '#4cff8a'); } else { diamond(g, 5, gy2, P.gold2); diamond(g, W - 6, gy2, P.gold2); } }
    // pockets
    pocket(g, R + 1, R + 1, 6); pocket(g, W - R - 2, R + 1, 6); pocket(g, R + 1, H - R - 2, 6); pocket(g, W - R - 2, H - R - 2, 6);
    pocket(g, R - 2, H >> 1, 5); pocket(g, W - R + 1, H >> 1, 5);
    tableCache = c;
    return c;
  }
  var SPARK = [];
  (function () { var r = rng(5); for (var i = 0; i < 16; i++) SPARK.push([r(), r(), r() * 3000]); })();
  G.table = function (now) {
    if (!tableCache) buildTable();
    ctx.drawImage(tableCache, 0, 0);
    var R = G.TR + 6, i, s, ph, x, y;
    for (i = 0; i < SPARK.length; i++) {
      s = SPARK[i]; ph = ((now + s[2]) % 3000) / 3000;
      if (ph > 0.12) continue;
      x = R + Math.floor(s[0] * (W - 2 * R)); y = R + Math.floor(s[1] * (H - 2 * R));
      ctx.fillStyle = 'rgba(255,255,230,0.85)'; ctx.fillRect(x, y, 1, 1);
      if (ph > 0.03 && ph < 0.09) { ctx.fillStyle = 'rgba(255,255,230,0.5)'; ctx.fillRect(x - 1, y, 3, 1); ctx.fillRect(x, y - 1, 1, 3); }
    }
  };
  G.invalidateTable = function () { tableCache = null; };

  /* -------------------------------------------------------- UI widgets */
  G.regions = [];
  G.pressId = null;
  G.region = function (id, x, y, w, h, cb, modal) { G.regions.push({ id: id, x: x, y: y, w: w, h: h, cb: cb, modal: !!modal }); };
  G.hit = function (px, py, modalOnly) {
    for (var i = G.regions.length - 1; i >= 0; i--) {
      var r = G.regions[i];
      if (modalOnly && !r.modal) continue;
      if (px >= r.x && px < r.x + r.w && py >= r.y && py < r.y + r.h) return r;
    }
    return null;
  };

  var BTN = {
    gold: { face: '#f0c040', hi: '#fff0a8', lo: '#b0841a', edge: '#4a3206', text: '#3a2406' },
    green: { face: '#3fbf6a', hi: '#a8f0c0', lo: '#1c7a3a', edge: '#063018', text: '#05260f' },
    red: { face: '#d6344a', hi: '#ff8fa0', lo: '#8c1426', edge: '#3a0610', text: '#ffffff' },
    wood: { face: '#8d5a2b', hi: '#c08a52', lo: '#4b2c14', edge: '#1e0f05', text: '#f6ead0' },
    off: { face: '#6e6250', hi: '#8a7e6a', lo: '#4a4234', edge: '#241d12', text: '#a89c86' }
  };
  G.button = function (id, x, y, w, h, label, o) {
    o = o || {};
    var st = BTN[o.disabled ? 'off' : (o.style || 'gold')], pressed = !o.disabled && G.pressId === id, oy = pressed ? 1 : 0;
    x = Math.round(x); y = Math.round(y);
    rect(ctx, x + 1, y + h, w - 2, 1, 'rgba(0,0,0,0.4)');
    rect(ctx, x + 1, y + oy, w - 2, h, st.edge); rect(ctx, x, y + 1 + oy, w, h - 2, st.edge);
    rect(ctx, x + 1, y + 1 + oy, w - 2, h - 2, st.face);
    if (!pressed) { rect(ctx, x + 2, y + 1, w - 4, 1, st.hi); rect(ctx, x + 1, y + h - 3, w - 2, 2, st.lo); }
    var ty;
    if (/^[\x20-\x7E]*$/.test(label) && !o.sys) { ty = y + oy + Math.round((h - 7 * (o.s || 1)) / 2); G.text(label, x + (w >> 1), ty, { c: st.text, s: o.s || 1, a: 'c' }); }
    else { var sz = o.size || 9; ty = y + oy + Math.round((h - sz * 1.2) / 2) - 1; G.text(label, x + (w >> 1), ty, { c: st.text, size: sz, a: 'c', bold: o.bold }); }
    if (o.icon) G.sprite(o.icon, x + 4, y + ((h - 5) >> 1), 1);
    if (!o.disabled && o.cb) G.region(id, x, y, w, h, o.cb, o.modal);
  };
  G.panel = function (x, y, w, h, kind) {
    x = Math.round(x); y = Math.round(y);
    rect(ctx, x + 2, y + 2, w, h, 'rgba(0,0,0,0.35)');
    if (kind === 'dark') {
      rect(ctx, x + 1, y, w - 2, h, P.gold1); rect(ctx, x, y + 1, w, h - 2, P.gold1);
      rect(ctx, x + 2, y + 1, w - 4, h - 2, '#1c1008'); rect(ctx, x + 1, y + 2, w - 2, h - 4, '#1c1008');
      rect(ctx, x + 3, y + 3, w - 6, 1, 'rgba(255,255,255,0.08)');
    } else if (kind === 'wood') {
      rect(ctx, x + 1, y, w - 2, h, P.wood0); rect(ctx, x, y + 1, w, h - 2, P.wood0);
      rect(ctx, x + 1, y + 1, w - 2, h - 2, P.wood2); rect(ctx, x + 2, y + 1, w - 4, 1, P.wood3);
    } else {
      rect(ctx, x + 1, y, w - 2, h, P.ink); rect(ctx, x, y + 1, w, h - 2, P.ink);
      rect(ctx, x + 1, y + 1, w - 2, h - 2, P.parch3); rect(ctx, x + 2, y + 2, w - 4, h - 4, P.parch);
      rect(ctx, x + 2, y + h - 4, w - 4, 2, P.parch2);
    }
  };
  // name plaque with score + hand wins; drawn on g (so it can be rotated)
  G.plaque = function (g, w, h, name, total, wins, o) {
    o = o || {};
    var pulse = o.active ? (0.5 + 0.5 * Math.sin((o.now || 0) / 180)) : 0;
    rect(g, 0, 2, w, h - 2, 'rgba(0,0,0,0.35)');
    rect(g, 1, 0, w - 2, h - 2, o.active ? (pulse > 0.5 ? P.gold3 : P.gold2) : P.gold1);
    rect(g, 0, 1, w, h - 4, o.active ? (pulse > 0.5 ? P.gold3 : P.gold2) : P.gold1);
    rect(g, 1, 1, w - 2, h - 4, '#1c1008'); rect(g, 2, 1, w - 4, h - 4 + 0, '#1c1008');
    rect(g, 2, 2, w - 4, 1, 'rgba(255,255,255,0.08)');
    var nm = G.fit(name, w - 40, { size: 9 });
    var nmOpts = { c: o.active ? P.gold3 : P.cream, size: 9, s: 1 };
    G.text(nm, 5, /^[\x20-\x7E]*$/.test(nm) ? 4 : 1, nmOpts, g);
    var i;
    for (i = 0; i < 3; i++) G.sprite(i < wins ? 'star' : 'starOff', 5 + i * 9, h - 12, 1, g);
    G.text(String(total), w - 4, Math.round((h - 4 - 14) / 2) + 1, { c: P.gold2, s: 2, a: 'r', sh: '#000000' }, g);
  };

  G.mk = mkCanvas;
})();
