/* Pixel Dice - logic.js
 * Pure game logic + network sessions. No DOM here, so it can be tested in Node.
 * Credit: Hirkan
 */
(function (root) {
  'use strict';

  var C = {
    NDICE: 5,
    MAX_ROLLS: 2,        // each turn a player may throw the dice twice
    FIRST_TARGET: 100,   // goal of hand 1
    TARGET_STEP: 100,    // every new hand adds 100 to the goal
    WINS_NEEDED: 3,      // hands needed to win the whole match
    PORT: 40404,
    VERSION: 1
  };

  var SKIN_NAMES = ['IVORY', 'RUBY', 'EMERALD', 'GOLD', 'ICE', 'GALAXY', 'LAVA', 'RAINBOW'];
  var LEVEL_XP = [0, 30, 80, 150, 250, 400, 600, 850];

  function fill(n, v) { var a = [], i; for (i = 0; i < n; i++) a.push(v); return a; }

  function levelFromXp(xp) {
    var l = 1, i;
    for (i = 0; i < LEVEL_XP.length; i++) if (xp >= LEVEL_XP[i]) l = i + 1;
    return l;
  }

  /* ---------------------------------------------------------------- scoring */
  // number of dice that have at least one twin among the given values
  // (2,2 -> 2 dice, 3,3 -> 2 dice, 4,4,4 -> 3 dice)
  function pairedCount(vals) {
    var cnt = [0, 0, 0, 0, 0, 0, 0], i, p = 0;
    for (i = 0; i < vals.length; i++) cnt[vals[i]]++;
    for (i = 1; i <= 6; i++) if (cnt[i] >= 2) p += cnt[i];
    return p;
  }
  function sumOf(vals) { var s = 0, i; for (i = 0; i < vals.length; i++) s += vals[i]; return s; }

  /* ------------------------------------------------------- legendary combos */
  // Evaluated on the SELECTED dice. Only the best combo counts; its bonus is added to the normal score.
  var COMBOS = {
    king6:   { bonus: 600, name: 'شاه شش‌ها',     desc: 'پنج تا شش' },
    five:    { bonus: 400, name: 'پنج‌تایی',        desc: 'پنج تاس یکسان' },
    dragon:  { bonus: 300, name: 'اژدهای طلایی',  desc: 'دو تا یک و سه تا شش' },
    phoenix: { bonus: 200, name: 'ققنوس',          desc: 'دو تا پنج و سه تا دو' },
    straight:{ bonus: 150, name: 'پله‌ی آسمان',   desc: 'پشت سر هم: ۱ تا ۵ یا ۲ تا ۶' },
    four:    { bonus: 100, name: 'چهارتایی',        desc: 'چهار تاس یکسان' },
    house:   { bonus: 60,  name: 'قصر',             desc: 'دو تا و سه تای یکسان' },
    parity:  { bonus: 40,  name: 'هم‌خانواده',     desc: 'پنج تاس همه زوج یا همه فرد' }
  };
  var COMBO_ORDER = ['king6', 'five', 'dragon', 'phoenix', 'straight', 'four', 'house', 'parity'];
  function comboOf(vals) {
    var n = vals.length, cnt = [0, 0, 0, 0, 0, 0, 0], i, v;
    for (i = 0; i < n; i++) cnt[vals[i]]++;
    var best = null;
    function offer(id) { if (!best || COMBOS[id].bonus > COMBOS[best].bonus) best = id; }
    var two = 0, three = 0, four = 0, five = 0, kinds = 0;
    for (v = 1; v <= 6; v++) {
      if (cnt[v]) kinds++;
      if (cnt[v] === 5) five = v; if (cnt[v] === 4) four = v; if (cnt[v] === 3) three = v; if (cnt[v] === 2) two = v;
    }
    if (five) offer(five === 6 ? 'king6' : 'five');
    if (n >= 4 && (four || five)) offer('four');
    if (n === 5 && three && two) {
      if (three === 6 && two === 1) offer('dragon');
      else if (three === 2 && two === 5) offer('phoenix');
      else offer('house');
    }
    if (n === 5 && kinds === 5 && ((!cnt[6]) || (!cnt[1]))) offer('straight');
    if (n === 5) {
      var ev = 0, od = 0;
      for (i = 0; i < n; i++) { if (vals[i] % 2) od++; else ev++; }
      if (ev === 5 || od === 5) offer('parity');
    }
    return best;
  }
  function baseScore(vals) { return sumOf(vals) * pairedCount(vals); }
  function scoreValues(vals) { var c = comboOf(vals); return baseScore(vals) + (c ? COMBOS[c].bonus : 0); }
  function selectedValues(dice, sel) {
    var v = [], i;
    for (i = 0; i < dice.length; i++) if (sel[i] && dice[i] > 0) v.push(dice[i]);
    return v;
  }
  function breakdown(dice, sel) {
    var v = selectedValues(dice, sel), s = sumOf(v), p = pairedCount(v), c = comboOf(v), bonus = c ? COMBOS[c].bonus : 0;
    return { sum: s, pairs: p, base: s * p, combo: c, bonus: bonus, score: s * p + bonus };
  }

  /* -------------------------------------------------------------------- bot */
  var evCache = {};   // EV only depends on the multiset of kept values and the number of re-thrown dice
  function expectedAfterReroll(dice, keep) {
    var kept = [], k = 0, i;
    for (i = 0; i < dice.length; i++) { if (keep[i]) kept.push(dice[i]); else k++; }
    if (k === 0) return scoreValues(dice);
    kept.sort();
    var key = kept.join('') + '|' + k;
    if (evCache[key] !== undefined) return evCache[key];
    var d = kept.slice(), total = 0, n = Math.pow(6, k), c, j, x, base = kept.length;
    for (j = 0; j < k; j++) d.push(1);
    for (c = 0; c < n; c++) {
      x = c;
      for (j = 0; j < k; j++) { d[base + j] = (x % 6) + 1; x = (x / 6) | 0; }
      total += scoreValues(d);
    }
    evCache[key] = total / n;
    return evCache[key];
  }
  // which dice to keep (true) so that the expected score after one more throw is maximal
  function botKeepPlan(dice) {
    var best = -1, bestMask = null, m, i, keep, ev;
    for (m = 31; m >= 0; m--) {
      keep = [];
      for (i = 0; i < 5; i++) keep.push(!!(m & (1 << i)));
      ev = expectedAfterReroll(dice, keep);
      if (ev > best + 1e-9) { best = ev; bestMask = keep; }
    }
    return bestMask;
  }

  /* ------------------------------------------------------------------ match */
  function Match(cfg) {
    var n = cfg.n;
    this.rng = cfg.rng || Math.random;
    this.s = {
      id: Math.floor(this.rng() * 1e9),
      n: n,
      names: cfg.names.slice(),
      skins: (cfg.skins || fill(n, 0)).slice(),
      bots: (cfg.bots || fill(n, false)).slice(),
      hand: 1,
      target: C.FIRST_TARGET,
      totals: fill(n, 0),
      wins: fill(n, 0),
      starter: 0,
      turn: 0,
      phase: 'await_roll',   // await_roll | await_action | scored | hand_over | match_over
      dice: fill(5, 0),
      sel: fill(5, true),
      rolls: 0,
      rollId: 0,
      rolled: fill(5, false),
      last: null,
      handWinner: -1,
      matchWinner: -1,
      seq: 0
    };
  }
  Match.prototype.snapshot = function () { return JSON.parse(JSON.stringify(this.s)); };
  Match.prototype._throw = function (idx) {
    var s = this.s, i, mask = fill(5, false);
    for (i = 0; i < idx.length; i++) {
      s.dice[idx[i]] = 1 + Math.floor(this.rng() * 6);
      mask[idx[i]] = true;
    }
    s.rolled = mask;
    s.rollId++;
  };
  Match.prototype._resetDice = function () {
    var s = this.s;
    s.dice = fill(5, 0); s.sel = fill(5, true); s.rolls = 0; s.rolled = fill(5, false);
  };
  // act: {a:'roll'} | {a:'toggle', i} | {a:'reroll'} | {a:'submit'}
  Match.prototype.apply = function (seat, act) {
    var s = this.s, i, idx;
    if (!act || seat !== s.turn) return false;
    if (s.phase === 'await_roll') {
      if (act.a !== 'roll') return false;
      this._throw([0, 1, 2, 3, 4]);
      s.rolls = 1; s.phase = 'await_action'; s.seq++;
      return true;
    }
    if (s.phase === 'await_action') {
      if (act.a === 'toggle') {
        i = act.i | 0;
        if (i < 0 || i > 4) return false;
        s.sel[i] = !s.sel[i]; s.seq++;
        return true;
      }
      if (act.a === 'reroll') {
        if (s.rolls >= C.MAX_ROLLS) return false;
        idx = [];
        for (i = 0; i < 5; i++) if (!s.sel[i]) idx.push(i);
        if (!idx.length) return false;
        this._throw(idx);
        for (i = 0; i < idx.length; i++) s.sel[idx[i]] = true;
        s.rolls++; s.seq++;
        return true;
      }
      if (act.a === 'submit') {
        var b = breakdown(s.dice, s.sel);
        s.totals[seat] += b.score;
        s.last = { seat: seat, score: b.score, sum: b.sum, pairs: b.pairs, combo: b.combo, bonus: b.bonus, dice: s.dice.slice(), sel: s.sel.slice() };
        s.phase = 'scored'; s.seq++;
        return true;
      }
    }
    return false;
  };
  Match.prototype.advance = function () {
    var s = this.s;
    if (s.phase !== 'scored') return false;
    var seat = s.turn;
    if (s.totals[seat] >= s.target) {            // first one to reach the goal wins the hand
      s.wins[seat]++;
      s.handWinner = seat;
      if (s.wins[seat] >= C.WINS_NEEDED) { s.phase = 'match_over'; s.matchWinner = seat; }
      else s.phase = 'hand_over';
    } else {
      s.turn = (s.turn + 1) % s.n;
      this._resetDice();
      s.phase = 'await_roll';
    }
    s.seq++;
    return true;
  };
  Match.prototype.nextHand = function () {
    var s = this.s;
    if (s.phase !== 'hand_over') return false;
    s.hand++;
    s.target = C.FIRST_TARGET + C.TARGET_STEP * (s.hand - 1);
    s.totals = fill(s.n, 0);
    s.starter = (s.starter + 1) % s.n;           // the starting player rotates every hand
    s.turn = s.starter;
    s.handWinner = -1;
    s.last = null;
    this._resetDice();
    s.phase = 'await_roll';
    s.seq++;
    return true;
  };

  /* ------------------------------------------------------------- controller */
  // Owns a Match, runs the timers (scoring pause, next hand) and the bot.
  var DEFAULT_DELAYS = { scored: 1500, handOver: 3400, botRoll: 1000, botThink: 1500, botToggle: 450 };

  function Controller(cfg) {
    this.cfg = cfg;
    this.match = new Match(cfg);
    this.onChange = cfg.onChange || function () {};
    this.delay = {};
    var k, d = cfg.delays || {};
    for (k in DEFAULT_DELAYS) this.delay[k] = d[k] !== undefined ? d[k] : DEFAULT_DELAYS[k];
    this.setTimer = cfg.setTimer || function (f, ms) { return setTimeout(f, ms); };
    this.clearTimer = cfg.clearTimer || function (t) { clearTimeout(t); };
    this.timer = null; this.stopped = false; this._plan = null;
  }
  Controller.prototype.start = function () { this._changed(); };
  Controller.prototype.stop = function () {
    this.stopped = true;
    if (this.timer !== null) { this.clearTimer(this.timer); this.timer = null; }
  };
  Controller.prototype.snapshot = function () { return this.match.snapshot(); };
  Controller.prototype.act = function (seat, a) {
    if (this.stopped) return false;
    var ok = this.match.apply(seat, a);
    if (ok) this._changed();
    return ok;
  };
  Controller.prototype._changed = function () {
    this.onChange(this.match.snapshot());
    this._schedule();
  };
  Controller.prototype._later = function (ms, fn) {
    var self = this;
    if (this.timer !== null) this.clearTimer(this.timer);
    this.timer = this.setTimer(function () { self.timer = null; if (!self.stopped) fn(); }, ms);
  };
  Controller.prototype._schedule = function () {
    var self = this, s = this.match.s, d = this.delay;
    if (this.timer !== null) { this.clearTimer(this.timer); this.timer = null; }
    if (this.stopped) return;
    if (s.phase === 'scored') { this._later(d.scored, function () { self.match.advance(); self._changed(); }); return; }
    if (s.phase === 'hand_over') { this._later(d.handOver, function () { self.match.nextHand(); self._changed(); }); return; }
    if (s.phase === 'match_over') return;
    if (s.bots[s.turn]) {
      var step = this._botStep(), seat = s.turn;
      if (step) this._later(step.delay, function () { self.act(seat, step.a); });
    }
  };
  Controller.prototype._botStep = function () {
    var s = this.match.s, d = this.delay, i, free = false;
    if (s.phase === 'await_roll') return { delay: d.botRoll, a: { a: 'roll' } };
    if (s.phase !== 'await_action') return null;
    if (s.rolls >= C.MAX_ROLLS) return { delay: d.botThink, a: { a: 'submit' } };
    if (!this._plan || this._plan.rollId !== s.rollId) this._plan = { rollId: s.rollId, keep: botKeepPlan(s.dice) };
    var firstMove = true;
    for (i = 0; i < 5; i++) if (!s.sel[i]) { free = true; firstMove = false; }
    for (i = 0; i < 5; i++) {
      if (!this._plan.keep[i] && s.sel[i]) return { delay: firstMove ? d.botThink : d.botToggle, a: { a: 'toggle', i: i } };
    }
    if (free) return { delay: Math.round(d.botToggle * 1.35), a: { a: 'reroll' } };
    return { delay: d.botThink, a: { a: 'submit' } };
  };

  /* --------------------------------------------------------- host / guest */
  // tx (host):  sendTo(id, str) sendAll(str) drop(id)
  // tx (guest): sendHost(str)
  function uniqueName(name, taken) {
    var base = String(name || 'PLAYER').replace(/\s+/g, ' ').trim().slice(0, 12) || 'PLAYER';
    var cand = base, k = 2, low = taken.map(function (x) { return String(x).toLowerCase(); });
    while (low.indexOf(cand.toLowerCase()) >= 0) { cand = base.slice(0, 10) + ' ' + k; k++; }
    return cand;
  }

  function HostSession(tx, cfg, cb) {
    this.tx = tx; this.cfg = cfg; this.cb = cb || {};
    this.n = cfg.n;
    this.me = { name: uniqueName(cfg.name, []), skin: cfg.skin | 0 };
    this.peers = [];       // {id, name, skin, ok}
    this.ctrl = null;
    this.started = false;
    this.closed = false;
    this.startTimer = null;
    this.setTimer = cfg.setTimer || function (f, ms) { return setTimeout(f, ms); };
    this.clearTimer = cfg.clearTimer || function (t) { clearTimeout(t); };
  }
  HostSession.prototype._send = function (id, obj) { this.tx.sendTo(id, JSON.stringify(obj)); };
  HostSession.prototype._all = function (obj) { this.tx.sendAll(JSON.stringify(obj)); };
  HostSession.prototype.lobby = function () {
    var names = [this.me.name], skins = [this.me.skin], ok = [true], i;
    for (i = 0; i < this.n - 1; i++) {
      var p = this.peers[i];
      names.push(p && p.ok ? p.name : null);
      skins.push(p && p.ok ? p.skin : 0);
      ok.push(!!(p && p.ok));
    }
    var full = ok.every(function (x) { return x; });
    return { t: 'lobby', n: this.n, names: names, skins: skins, ok: ok, full: full };
  };
  HostSession.prototype._pushLobby = function () {
    var l = this.lobby(), i;
    for (i = 0; i < this.peers.length; i++) this._send(this.peers[i].id, { t: 'welcome', seat: i + 1, n: this.n });
    this._all(l);
    if (this.cb.onLobby) this.cb.onLobby(l);
    if (l.full && !this.started && !this.startTimer) {
      var self = this;
      this.startTimer = this.setTimer(function () { self.startTimer = null; self.startNow(); },
        this.cfg.startDelay !== undefined ? this.cfg.startDelay : 1800);
    }
  };
  HostSession.prototype.onEvent = function (kind, id, data) {
    var i, p, m;
    if (this.closed) return;
    if (kind === 'client_in') {
      if (this.started || this.peers.length >= this.n - 1) { this.tx.drop(id); return; }
      this.peers.push({ id: id, name: null, skin: 0, ok: false });
    } else if (kind === 'client_out') {
      for (i = 0; i < this.peers.length; i++) if (this.peers[i].id === id) break;
      if (i >= this.peers.length) return;
      this.peers.splice(i, 1);
      if (this.started) { this._finish('peer_left'); return; }
      if (this.startTimer) { this.clearTimer(this.startTimer); this.startTimer = null; }
      this._pushLobby();
    } else if (kind === 'msg') {
      try { m = JSON.parse(data); } catch (e) { return; }
      for (i = 0; i < this.peers.length; i++) if (this.peers[i].id === id) break;
      if (i >= this.peers.length) return;
      p = this.peers[i];
      if (m.t === 'hello' && !this.started) {
        var taken = [this.me.name];
        this.peers.forEach(function (q) { if (q !== p && q.ok) taken.push(q.name); });
        p.name = uniqueName(m.name, taken); p.skin = m.skin | 0; p.ok = true;
        this._pushLobby();
      } else if (m.t === 'act' && this.started && this.ctrl) {
        this.ctrl.act(i + 1, { a: m.a, i: m.i });
      }
    }
  };
  HostSession.prototype._makeController = function () {
    var self = this, names = [this.me.name], skins = [this.me.skin], bots = [false], i;
    for (i = 0; i < this.peers.length; i++) { names.push(this.peers[i].name); skins.push(this.peers[i].skin); bots.push(false); }
    this.ctrl = new Controller({
      n: this.n, names: names, skins: skins, bots: bots, delays: this.cfg.delays,
      setTimer: this.cfg.setTimer, clearTimer: this.cfg.clearTimer,
      onChange: function (s) { self._all({ t: 'state', s: s }); if (self.cb.onState) self.cb.onState(s); }
    });
  };
  HostSession.prototype.startNow = function () {
    if (this.started || this.closed) return;
    var l = this.lobby();
    if (!l.full) return;
    this.started = true;
    this._makeController();
    this._all({ t: 'start' });
    if (this.cb.onStart) this.cb.onStart();
    this.ctrl.start();
  };
  HostSession.prototype.rematch = function () {
    if (!this.started || this.closed) return;
    if (this.ctrl) this.ctrl.stop();
    this._makeController();
    this.ctrl.start();
  };
  HostSession.prototype.act = function (a) { return this.ctrl ? this.ctrl.act(0, a) : false; };
  HostSession.prototype._finish = function (reason) {
    if (this.closed) return;
    this.close();
    if (this.cb.onEnd) this.cb.onEnd(reason);
  };
  HostSession.prototype.close = function () {
    this.closed = true;
    if (this.ctrl) this.ctrl.stop();
    if (this.startTimer) { this.clearTimer(this.startTimer); this.startTimer = null; }
  };

  function GuestSession(tx, cfg, cb) {
    this.tx = tx; this.cfg = cfg; this.cb = cb || {};
    this.seat = -1; this.n = 0; this.closed = false; this.state = null; this.lobby = null; this.helloSent = false;
  }
  GuestSession.prototype._hello = function () {
    if (this.helloSent) return;
    this.helloSent = true;
    this.tx.sendHost(JSON.stringify({ t: 'hello', v: C.VERSION, name: this.cfg.name, skin: this.cfg.skin | 0 }));
  };
  GuestSession.prototype.onEvent = function (kind, id, data) {
    var m;
    if (this.closed) return;
    if (kind === 'connected') { this._hello(); if (this.cb.onConnected) this.cb.onConnected(); return; }
    if (kind === 'disconnected') { this.closed = true; if (this.cb.onEnd) this.cb.onEnd('host_left'); return; }
    if (kind === 'error') { this.closed = true; if (this.cb.onError) this.cb.onError(data); return; }
    if (kind !== 'msg') return;
    try { m = JSON.parse(data); } catch (e) { return; }
    if (m.t === 'welcome') { this.seat = m.seat; this.n = m.n; if (this.cb.onWelcome) this.cb.onWelcome(m.seat, m.n); }
    else if (m.t === 'lobby') { this.lobby = m; if (this.cb.onLobby) this.cb.onLobby(m); }
    else if (m.t === 'start') { if (this.cb.onStart) this.cb.onStart(); }
    else if (m.t === 'state') { this.state = m.s; if (this.cb.onState) this.cb.onState(m.s); }
  };
  GuestSession.prototype.act = function (a) {
    if (this.closed) return false;
    this.tx.sendHost(JSON.stringify({ t: 'act', a: a.a, i: a.i }));
    return true;
  };
  GuestSession.prototype.close = function () { this.closed = true; };

  var api = {
    C: C, SKIN_NAMES: SKIN_NAMES, LEVEL_XP: LEVEL_XP, levelFromXp: levelFromXp,
    pairedCount: pairedCount, scoreValues: scoreValues, breakdown: breakdown, comboOf: comboOf, COMBOS: COMBOS, COMBO_ORDER: COMBO_ORDER,
    expectedAfterReroll: expectedAfterReroll, botKeepPlan: botKeepPlan,
    Match: Match, Controller: Controller, HostSession: HostSession, GuestSession: GuestSession,
    uniqueName: uniqueName
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.DD = api;
})(typeof window !== 'undefined' ? window : globalThis);
