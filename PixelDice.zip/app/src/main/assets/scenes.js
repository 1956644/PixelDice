/* Pixel Dice - scenes.js : animated fantasy rooms
 *   G.table(now)      : rectangular green table (menu, bot game, 2-player game): cat, candle, lanterns
 *   G.tableRound(now) : round wooden table with chairs (3-player game): candles, lantern, lightning
 * Credit: Hirkan
 */
(function () {
  'use strict';
  var G = window.G, ctx = G.ctx, P = G.P, rng = G.rng;
  function rect(g, x, y, w, h, c) { g.fillStyle = c; g.fillRect(Math.round(x), Math.round(y), Math.round(w), Math.round(h)); }
  function hash(n) { var x = Math.sin(n * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); }
  var BAYER = [[0, 8, 2, 10], [12, 4, 14, 6], [3, 11, 1, 9], [15, 7, 13, 5]];

  /* ---------------------------------------------------------------- glow */
  var glowC = {};
  function glowSprite(r, rgb) {
    var key = r + '|' + rgb;
    if (glowC[key]) return glowC[key];
    var d = r * 2 + 1, c = G.mk(d, d), g = c.getContext('2d'), x, y, dist, t, lvl;
    for (y = 0; y < d; y++) for (x = 0; x < d; x++) {
      dist = Math.sqrt((x - r) * (x - r) + (y - r) * (y - r)); if (dist > r) continue;
      t = 1 - dist / r; lvl = Math.floor(t * t * 5 + BAYER[y & 3][x & 3] / 16);
      if (lvl <= 0) continue;
      g.fillStyle = 'rgba(' + rgb + ',' + (0.075 * Math.min(lvl, 4)) + ')'; g.fillRect(x, y, 1, 1);
    }
    glowC[key] = c; return c;
  }
  function glow(cx, cy, r, rgb, alpha) {
    ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = Math.max(0, Math.min(1, alpha));
    ctx.drawImage(glowSprite(r, rgb), Math.round(cx - r), Math.round(cy - r)); ctx.restore();
  }
  function flicker(now, seed) {
    return 0.62 + 0.2 * Math.sin(now / 95 + seed * 5) + 0.12 * Math.sin(now / 41 + seed * 11) + 0.1 * (hash(Math.floor(now / 70) + seed * 31) - 0.5);
  }
  function flame(cx, baseY, now, seed) {
    var f = Math.floor(now / 85 + seed * 7) % 4, h = [5, 6, 5, 4][f], sw = [0, 1, 0, -1][Math.floor(now / 140 + seed * 3) % 4];
    rect(ctx, cx - 1, baseY - h + 1, 3, h - 1, '#ff7a1a');
    rect(ctx, cx + sw, baseY - h, 1, 2, '#ff7a1a');
    rect(ctx, cx, baseY - h + 2, 1, h - 2, '#ffd24a');
    rect(ctx, cx, baseY - 2, 1, 1, '#fffbe0');
  }

  /* --------------------------------------------------------------- shapes */
  function chamfer(g, x, y, w, h, cut, col) {
    var k;
    cut = Math.max(0, cut);
    for (k = 0; k < cut; k++) { rect(g, x + (cut - k), y + k, w - 2 * (cut - k), 1, col); rect(g, x + (cut - k), y + h - 1 - k, w - 2 * (cut - k), 1, col); }
    rect(g, x, y + cut, w, h - 2 * cut, col);
  }
  function diamond(g, cx, cy, col) { rect(g, cx, cy - 2, 1, 5, col); rect(g, cx - 1, cy - 1, 3, 3, col); rect(g, cx - 2, cy, 5, 1, col); rect(g, cx, cy, 1, 1, P.gold3); }
  function gem(g, cx, cy, col) { rect(g, cx - 1, cy - 1, 3, 3, col); rect(g, cx - 1, cy - 1, 1, 1, '#ffffff'); }

  function books(g, x0, x1, bottom, hmin, hmax, seed) {
    var r = rng(seed), x = x0, cols = ['#6b2fa0', '#2f4fa0', '#a0302f', '#2f7a4a', '#b08a2f', '#503070', '#8a4a20', '#3a6a8a'];
    while (x < x1) {
      var w = 3 + Math.floor(r() * 3), h = hmin + Math.floor(r() * (hmax - hmin)), c = cols[Math.floor(r() * cols.length)];
      if (r() < 0.12) { x += 2; continue; }
      rect(g, x, bottom - h, w, h, c); rect(g, x, bottom - h, 1, h, 'rgba(255,255,255,0.18)'); rect(g, x + w - 1, bottom - h, 1, h, 'rgba(0,0,0,0.35)');
      rect(g, x + 1, bottom - h + 2, w - 2, 1, '#e0c070');
      x += w;
    }
  }
  function plant(g, x, y, s, seed) {                      // x,y = pot bottom centre
    var r = rng(seed), i;
    rect(g, x - 4, y - 7, 9, 7, '#7a3a1c'); rect(g, x - 4, y - 7, 9, 1, '#a8582a'); rect(g, x - 3, y, 7, 1, '#4a210e');
    for (i = 0; i < 16; i++) {
      var a = -Math.PI * (0.1 + 0.8 * r()), l = (7 + r() * 10) * s, lx = x + Math.cos(a) * l, ly = y - 8 + Math.sin(a) * l;
      rect(g, lx - 1, ly - 1, 3, 2, r() < 0.5 ? '#2f8a3a' : '#1c6a2c'); rect(g, lx, ly - 1, 1, 1, '#6adf7a');
    }
  }
  function lantern(g, cx, top) {                           // 7 wide, 12 tall
    rect(g, cx - 3, top, 7, 2, P.gold0); rect(g, cx - 1, top - 2, 3, 2, P.gold0);
    rect(g, cx - 3, top + 2, 7, 8, '#3a2410'); rect(g, cx - 2, top + 3, 5, 6, '#ffb83a');
    rect(g, cx, top + 2, 1, 8, '#3a2410'); rect(g, cx - 3, top + 10, 7, 2, P.gold0);
  }
  function candleBody(g, cx, top) {                        // candle with holder; top = y of wick base
    rect(g, cx - 2, top, 4, 9, '#f1e4c0'); rect(g, cx - 2, top, 1, 9, '#fffbe8'); rect(g, cx + 1, top, 1, 9, '#c8b888');
    rect(g, cx - 1, top - 1, 2, 1, '#6a5030');
    rect(g, cx - 4, top + 9, 8, 2, '#4a3a5a'); rect(g, cx - 3, top + 11, 6, 1, '#2a2038'); rect(g, cx - 5, top + 12, 10, 1, '#4a3a5a');
  }

  /* ----------------------------------------------------------------- cat */
  var CAT = [
    '..k........k..', '..kk......kk..', '..kkkkkkkkkk..', '.kkkkkkkkkkkk.', '.kkeekkkkeekk.', '.kkeekkkkeekk.',
    '.kkkkknnkkkkk.', '..kkkkkkkkkk..', '..kkkkkkkkkk..', '.kkkkkkkkkkkk.', '.kkkkkkkkkkkk.', '.kkkkkkkkkkkk.', '.kkkkkkkkkkkk.', '.kk.kkkkkk.kk.'
  ];
  function drawCat(x, y, now) {                            // x,y = top-left of cat
    var rows = CAT.map(function (r) { return r.split(''); }), cx, cy, r, c;
    var blink = (now % 3800) > 3650, twitch = (now % 5300) > 5150, breath = Math.floor(now / 1100) % 2;
    if (blink) { for (cx = 0; cx < 14; cx++) { if (rows[4][cx] === 'e') rows[4][cx] = 'k'; if (rows[5][cx] === 'e') rows[5][cx] = 'd'; } }
    if (twitch) { rows[0][2] = '.'; rows[1][2] = '.'; rows[1][3] = 'k'; }
    var oy = breath ? 0 : 0;
    // tail
    var t, tx, ty, sway;
    for (t = 0; t < 11; t++) {
      sway = Math.sin(now / 430 + t * 0.42) * t * 0.34;
      tx = x + 13 + Math.sin(t / 10 * 2.3) * 5 + sway; ty = y + 13 - t * 1.25;
      rect(ctx, tx, ty, 2, 2, t > 8 ? '#3d2f66' : '#1b1428');
    }
    for (cy = 0; cy < rows.length; cy++) for (cx = 0; cx < 14; cx++) {
      c = rows[cy][cx]; if (c === '.') continue;
      var col = c === 'k' ? '#1b1428' : c === 'e' ? '#ffd23a' : c === 'n' ? '#ff8fa8' : '#07040c';
      if (c === 'k' && (cy === 0 || rows[cy - 1][cx] === '.' || rows[cy][cx - 1] === '.')) col = '#3d2f66';
      rect(ctx, x + cx, y + cy + (cy > 6 ? breath * 0 : 0), 1, 1, col);
    }
    if (!blink) { rect(ctx, x + 3, y + 4, 1, 1, '#fffbe0'); rect(ctx, x + 9, y + 4, 1, 1, '#fffbe0'); }
    rect(ctx, x - 2, y + 6, 2, 1, '#8a7aa8'); rect(ctx, x - 3, y + 5, 1, 1, '#8a7aa8'); rect(ctx, x + 14, y + 6, 2, 1, '#8a7aa8'); rect(ctx, x + 16, y + 5, 1, 1, '#8a7aa8');
    if (breath) rect(ctx, x + 2, y + 13, 10, 1, '#120c1c');
    // eye glow
    if (!blink) { glow(x + 4, y + 5, 7, '255,210,60', 0.25); glow(x + 10, y + 5, 7, '255,210,60', 0.25); }
  }

  /* ------------------------------------------------------- rectangular room */
  var rectCache = null, rectKey = '', rectLights = [];
  function buildRect() {
    var W = G.W, H = G.H, c = G.mk(W, H), g = c.getContext('2d'), r = rng(21), x, y, i;
    g.imageSmoothingEnabled = false;
    rect(g, 0, 0, W, H, '#1b1024');
    for (y = 0; y < H; y += 6) for (x = -(((y / 6) | 0) % 2) * 14; x < W; x += 28) {
      rect(g, x, y, 27, 5, r() < 0.5 ? '#21152c' : '#180e21'); rect(g, x, y + 5, 28, 1, '#0e0715'); rect(g, x + 27, y, 1, 6, '#0e0715');
    }
    // bookshelf wall (top)
    rect(g, 0, 0, W, 46, '#241338');
    for (x = 0; x < W; x += 7) rect(g, x, 0, 1, 46, '#1c0e2c');
    books(g, 0, W, 20, 10, 17, 3); rect(g, 0, 20, W, 3, '#6b3f1c'); rect(g, 0, 20, W, 1, '#8d5a2b'); rect(g, 0, 23, W, 2, 'rgba(0,0,0,0.35)');
    books(g, 0, W - 40, 43, 12, 19, 8); rect(g, 0, 43, W, 3, '#6b3f1c'); rect(g, 0, 43, W, 1, '#8d5a2b'); rect(g, 0, 46, W, 3, 'rgba(0,0,0,0.4)');
    rect(g, W - 42, 24, 42, 19, '#241338');                                // empty spot where the cat sits
    books(g, W - 42, W - 14, 43, 5, 7, 12);                                // little book stack under the cat
    // wall banner (top-left)
    rect(g, 4, 0, 14, 17, '#5a2a8a'); rect(g, 4, 0, 14, 2, '#c8962a'); rect(g, 4, 15, 3, 3, '#5a2a8a'); rect(g, 15, 15, 3, 3, '#5a2a8a'); rect(g, 10, 6, 2, 5, '#f0c040'); rect(g, 8, 8, 6, 1, '#f0c040');
    // side walls
    var TX = 12, TY = 50, TW = W - 24, TH = H - TY - 14;
    for (y = 49; y < H; y++) { rect(g, 0, y, TX, 1, (y % 7 === 0) ? '#150a1d' : '#1d1028'); rect(g, W - TX, y, TX, 1, (y % 7 === 0) ? '#150a1d' : '#1d1028'); }
    // clutter outside the table
    plant(g, 7, H - 8, 0.9, 5); plant(g, W - 8, H - 7, 0.8, 9);
    rect(g, 1, Math.round(H * 0.55), 9, 12, '#5a2a8a'); rect(g, 1, Math.round(H * 0.55), 9, 2, '#c8962a'); rect(g, 4, Math.round(H * 0.55) + 4, 3, 4, '#f0c040');   // spell book
    var py = Math.round(H * 0.58);
    rect(g, W - 11, py + 3, 8, 7, '#8a3aa8'); rect(g, W - 9, py, 4, 4, '#6a2a88'); rect(g, W - 10, py + 4, 2, 2, '#d89aff'); rect(g, W - 9, py - 2, 4, 2, '#7a5a3a');  // potion
    for (i = 0; i < 6; i++) { rect(g, W - 11 + (i % 3) * 3, py + 14 + ((i / 3) | 0) * 3, 3, 2, i % 2 ? '#f0c040' : '#c8962a'); }   // coins
    // ---- table
    chamfer(g, TX, TY, TW, TH, 7, '#1e0f05');
    chamfer(g, TX + 1, TY + 1, TW - 2, TH - 2, 6, '#8d5a2b');
    chamfer(g, TX + 2, TY + 2, TW - 4, TH - 4, 5, '#6b3f1c');
    chamfer(g, TX + 4, TY + 4, TW - 8, TH - 8, 4, P.gold1);
    chamfer(g, TX + 5, TY + 5, TW - 10, TH - 10, 4, '#4b2c14');
    // wood grain
    for (i = 0; i < 260; i++) {
      var side = Math.floor(r() * 4), len = 5 + Math.floor(r() * 12), col = r() < 0.5 ? '#7d4c22' : '#4a2810';
      if (side === 0) rect(g, TX + 8 + r() * (TW - 30), TY + 2 + r() * 2, len, 1, col);
      else if (side === 1) rect(g, TX + 8 + r() * (TW - 30), TY + TH - 3 - r() * 2, len, 1, col);
      else if (side === 2) rect(g, TX + 2 + r() * 2, TY + 8 + r() * (TH - 30), 1, len, col);
      else rect(g, TX + TW - 3 - r() * 2, TY + 8 + r() * (TH - 30), 1, len, col);
    }
    // felt
    var fx = TX + 7, fy = TY + 7, fw = TW - 14, fh = TH - 14;
    chamfer(g, fx, fy, fw, fh, 3, P.felt0);
    var id = g.getImageData(fx, fy, fw, fh), d = id.data, lv = [P.felt0, P.felt1, P.felt2, P.felt3].map(function (h) { var n = parseInt(h.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; });
    var ccx = fw / 2, ccy = G.diceCY - fy, nx, ny, dd, v, l, p;
    for (y = 0; y < fh; y++) for (x = 0; x < fw; x++) {
      p = (y * fw + x) * 4; if (d[p + 3] === 0) continue;
      nx = (x - ccx) / (fw / 2); ny = (y - ccy) / (fh / 2);
      dd = Math.min(1.2, Math.sqrt(nx * nx * 0.9 + ny * ny * 0.7));
      v = 0.55 + 2.05 * Math.pow(1 - Math.min(1, dd), 1.15);
      l = Math.floor(v + BAYER[y & 3][x & 3] / 16); l = l < 0 ? 0 : (l > 3 ? 3 : l);
      d[p] = lv[l][0]; d[p + 1] = lv[l][1]; d[p + 2] = lv[l][2]; d[p + 3] = 255;
    }
    g.putImageData(id, fx, fy);
    g.fillStyle = 'rgba(255,255,255,0.045)';
    for (y = fy; y < fy + fh; y++) { for (x = fx + (y % 14); x < fx + fw; x += 14) g.fillRect(x, y, 1, 1); for (x = fx + (13 - (y % 14)); x < fx + fw; x += 14) g.fillRect(x, y, 1, 1); }
    // inner gold frame line on the felt + corner ornaments
    g.strokeStyle = 'rgba(240,192,64,0.45)'; g.lineWidth = 1; g.strokeRect(fx + 4.5, fy + 4.5, fw - 9, fh - 9);
    [[fx + 4, fy + 4], [fx + fw - 5, fy + 4], [fx + 4, fy + fh - 5], [fx + fw - 5, fy + fh - 5]].forEach(function (q) { diamond(g, q[0], q[1], P.gold2); });
    // crown emblem near the top of the felt
    var ex = W >> 1, ey = fy + 12;
    rect(g, ex - 5, ey + 3, 11, 3, 'rgba(240,192,64,0.35)'); rect(g, ex - 5, ey, 2, 3, 'rgba(240,192,64,0.35)'); rect(g, ex - 1, ey - 2, 3, 5, 'rgba(240,192,64,0.35)'); rect(g, ex + 4, ey, 2, 3, 'rgba(240,192,64,0.35)');
    // magic ring
    var cxr = W >> 1, cyr = G.diceCY, rr = 50, a;
    for (a = 0; a < 360; a += 3) {
      var rx = Math.round(cxr + Math.cos(a * Math.PI / 180) * rr), ry = Math.round(cyr + Math.sin(a * Math.PI / 180) * rr * 0.62);
      g.fillStyle = (a % 30 === 0) ? 'rgba(240,192,64,0.8)' : 'rgba(255,255,255,0.16)'; g.fillRect(rx, ry, 1, 1);
    }
    [0, 90, 180, 270].forEach(function (aa) { diamond(g, Math.round(cxr + Math.cos(aa * Math.PI / 180) * rr), Math.round(cyr + Math.sin(aa * Math.PI / 180) * rr * 0.62), P.gold2); });
    // rail jewels
    for (i = 1; i <= 5; i++) { x = TX + Math.round(TW * i / 6); if (i === 3) { gem(g, x, TY + 3, '#4aa3ff'); gem(g, x, TY + TH - 4, '#ff5a6e'); } else { diamond(g, x, TY + 3, P.gold2); diamond(g, x, TY + TH - 4, P.gold2); } }
    for (i = 1; i <= 6; i++) { y = TY + Math.round(TH * i / 7); if (i === 3 || i === 4) { gem(g, TX + 3, y, '#4cff8a'); gem(g, TX + TW - 4, y, '#4cff8a'); } else { diamond(g, TX + 3, y, P.gold2); diamond(g, TX + TW - 4, y, P.gold2); } }
    // lanterns and candle (static parts)
    var lyA = Math.round(H * 0.22), lyB = Math.round(H * 0.8), cdy = Math.round(H * 0.36);
    lantern(g, 6, lyA); lantern(g, W - 7, lyB); candleBody(g, W - 6, cdy);
    rectLights = [
      { x: 6, y: lyA + 6, r: 26, rgb: '255,170,60', seed: 1, a: 0.5, kind: 'lantern' },
      { x: W - 7, y: lyB + 6, r: 26, rgb: '255,170,60', seed: 2, a: 0.5, kind: 'lantern' },
      { x: W - 6, y: cdy - 3, r: 40, rgb: '255,150,50', seed: 3, a: 0.62, kind: 'candle', fy: cdy }
    ];
    rectCache = c; rectKey = W + 'x' + H + ':' + G.diceCY;
  }
  var SPARK = []; (function () { var r = rng(5); for (var i = 0; i < 16; i++) SPARK.push([r(), r(), r() * 3000]); })();

  G.table = function (now) {
    var key = G.W + 'x' + G.H + ':' + G.diceCY;
    if (!rectCache || rectKey !== key) buildRect();
    ctx.drawImage(rectCache, 0, 0);
    var W = G.W, i, s, ph, x, y, L;
    // felt sparkles
    for (i = 0; i < SPARK.length; i++) {
      s = SPARK[i]; ph = ((now + s[2]) % 3000) / 3000; if (ph > 0.12) continue;
      x = 24 + Math.floor(s[0] * (W - 48)); y = 58 + Math.floor(s[1] * (G.H - 90));
      ctx.fillStyle = 'rgba(255,255,230,0.85)'; ctx.fillRect(x, y, 1, 1);
      if (ph > 0.03 && ph < 0.09) { ctx.fillStyle = 'rgba(255,255,230,0.5)'; ctx.fillRect(x - 1, y, 3, 1); ctx.fillRect(x, y - 1, 1, 3); }
    }
    drawCat(W - 38, 29, now);
    for (i = 0; i < rectLights.length; i++) {
      L = rectLights[i];
      glow(L.x, L.y, L.r, L.rgb, L.a * flicker(now, L.seed));
      if (L.kind === 'candle') flame(L.x, L.fy, now, L.seed);
      else if (L.kind === 'lantern') { glow(L.x, L.y, 8, '255,220,120', 0.55 * flicker(now, L.seed + 3)); }
    }
  };

  /* ------------------------------------------------------------ round room */
  var roundCache = null, roundKey = '', roundInfo = null;
  function chair(g, x, y, w, h, body, hi, lo, vertical) {
    chamfer(g, x, y, w, h, 3, '#2a1608'); chamfer(g, x + 1, y + 1, w - 2, h - 2, 2, '#8d5a2b');
    chamfer(g, x + 3, y + 3, w - 6, h - 6, 2, body);
    if (vertical) { rect(g, x + 3, y + 3, 1, h - 6, hi); rect(g, x + w - 4, y + 3, 1, h - 6, lo); } else { rect(g, x + 4, y + 3, w - 8, 1, hi); rect(g, x + 4, y + h - 4, w - 8, 1, lo); }
    var k, bx, by;
    for (k = 0; k < 6; k++) { if (vertical) { bx = x + (w >> 1); by = y + 6 + Math.floor((h - 12) * k / 5); } else { bx = x + 6 + Math.floor((w - 12) * k / 5); by = y + (h >> 1); } rect(g, bx, by, 1, 1, lo); rect(g, bx - 1, by - 1, 1, 1, hi); }
  }
  function buildRound() {
    var W = G.W, H = G.H, c = G.mk(W, H), g = c.getContext('2d'), r = rng(33), x, y, i;
    g.imageSmoothingEnabled = false;
    // parquet floor
    rect(g, 0, 0, W, H, '#1a1020');
    for (y = 0; y < H; y += 14) for (x = 0; x < W; x += 14) {
      var horiz = (((x / 14) | 0) + ((y / 14) | 0)) % 2 === 0, base = r() < 0.5 ? '#2b1a2c' : '#22142a';
      for (i = 0; i < 14; i += 3) { if (horiz) { rect(g, x, y + i, 14, 2, base); rect(g, x, y + i + 2, 14, 1, '#120a18'); } else { rect(g, x + i, y, 2, 14, base); rect(g, x + i + 2, y, 1, 14, '#120a18'); } }
    }
    rect(g, 0, 0, W, H, 'rgba(20,20,70,0.25)');
    var cx = W >> 1, cy = G.diceCY, rt = Math.floor(Math.min(W * 0.43, H * 0.31));
    // rugs
    rect(g, 2, H - 62, 52, 44, '#3a1a5a'); rect(g, 4, H - 60, 48, 40, '#2a1048'); rect(g, 6, H - 58, 44, 36, '#4a2a7a');
    for (i = 0; i < 5; i++) { rect(g, 10 + i * 8, H - 50, 3, 3, '#c8962a'); rect(g, 10 + i * 8, H - 36, 3, 3, '#c8962a'); }
    rect(g, 22, H - 44, 10, 10, '#c8962a'); rect(g, 24, H - 42, 6, 6, '#2a1048');
    // top-left shelf: side table with candle and book + plant
    rect(g, 0, 0, 62, 44, '#2a1810'); for (x = 0; x < 62; x += 6) rect(g, x, 0, 1, 44, '#1e100a');
    rect(g, 3, 26, 52, 4, '#8d5a2b'); rect(g, 3, 26, 52, 1, '#b8844a'); rect(g, 6, 30, 3, 14, '#4b2c14'); rect(g, 49, 30, 3, 14, '#4b2c14');
    rect(g, 8, 20, 18, 6, '#2a3a5a'); rect(g, 8, 20, 18, 1, '#5a7aa8'); rect(g, 14, 22, 6, 1, '#c8962a');   // book
    plant(g, 44, 26, 0.75, 14);
    // bottom-right side table with candle and book
    rect(g, W - 56, H - 40, 56, 40, '#4b2c14'); rect(g, W - 56, H - 40, 56, 3, '#8d5a2b'); rect(g, W - 56, H - 40, 2, 40, '#2a1608');
    rect(g, W - 46, H - 50, 20, 10, '#2a5a5a'); rect(g, W - 46, H - 50, 20, 1, '#6adfd0'); rect(g, W - 40, H - 47, 8, 1, '#c8962a');
    // window top-right with curtain
    var wx = W - 54, wy = 2, ww = 46, wh = 44;
    rect(g, wx - 3, wy, ww + 6, wh + 4, '#2a1608'); rect(g, wx - 2, wy + 1, ww + 4, wh + 2, '#6b3f1c');
    rect(g, wx, wy + 3, ww, wh - 2, '#0e1634');
    for (y = 0; y < wh - 2; y++) { var t = y / wh; rect(g, wx, wy + 3 + y, ww, 1, 'rgba(' + Math.round(20 + 30 * t) + ',' + Math.round(30 + 40 * t) + ',' + Math.round(80 + 40 * t) + ',0.55)'); }
    for (i = 0; i < 9; i++) rect(g, wx + 3 + Math.floor(r() * (ww - 6)), wy + 6 + Math.floor(r() * 20), 1, 1, '#b8d8ff');   // stars
    rect(g, wx + 30, wy + 8, 6, 6, '#e8f0ff'); rect(g, wx + 32, wy + 7, 4, 1, '#e8f0ff'); rect(g, wx + 33, wy + 8, 4, 4, '#0e1634');  // moon
    rect(g, wx + (ww >> 1) - 1, wy + 3, 2, wh - 2, '#6b3f1c'); rect(g, wx, wy + (wh >> 1) + 1, ww, 2, '#6b3f1c');
    rect(g, wx + ww - 8, wy + 1, 12, wh + 6, '#2a2a6a'); for (i = 0; i < 6; i++) rect(g, wx + ww - 8 + i * 2, wy + 1, 1, wh + 6, '#1a1a4a'); // curtain
    rect(g, wx - 3, wy + wh + 3, ww + 6, 2, '#2a1608');
    // plant by the window (right)
    plant(g, W - 10, Math.round(H * 0.35), 0.8, 21);
    // chairs (behind the table)
    chair(g, cx - 26, cy - rt - 18, 52, 22, '#2a4ac0', '#6a8aff', '#18286a', false);           // top, blue
    chair(g, cx - rt - 16, cy - 28, 22, 56, '#1a8a8a', '#5adfd0', '#0e4a4a', true);              // left, teal
    chair(g, cx - 26, cy + rt - 4, 52, 22, '#a8284a', '#ff7f9a', '#5a1028', false);              // bottom, red
    rect(g, cx - rt - 6, cy + 30, 10, 3, 'rgba(0,0,0,0.3)');
    // table: circular
    function disc(rad, col) { var dy, hw; for (dy = -rad; dy <= rad; dy++) { hw = Math.round(Math.sqrt(rad * rad - dy * dy)); rect(g, cx - hw, cy + dy, hw * 2 + 1, 1, col); } }
    disc(rt + 4, 'rgba(0,0,0,0.35)');
    disc(rt, '#24120a'); disc(rt - 1, '#9a6430'); disc(rt - 2, '#7a4a24'); disc(rt - 7, '#5a3318'); disc(rt - 8, '#c8962a'); disc(rt - 9, '#4a2810');
    // table top: dithered radial wood
    var sr = rt - 10, dy, dx, dist, v, l, cols = ['#4a2810', '#5e3518', '#744420', '#8a5428'];
    for (dy = -sr; dy <= sr; dy++) for (dx = -sr; dx <= sr; dx++) {
      dist = Math.sqrt(dx * dx + dy * dy); if (dist > sr) continue;
      v = 0.4 + 3.1 * Math.pow(1 - dist / sr, 0.9); l = Math.floor(v + BAYER[(cy + dy) & 3][(cx + dx) & 3] / 16); l = l < 0 ? 0 : (l > 3 ? 3 : l);
      g.fillStyle = cols[l]; g.fillRect(cx + dx, cy + dy, 1, 1);
    }
    for (i = 0; i < 90; i++) { var a0 = r() * 6.283, d0 = r() * (sr - 4); rect(g, cx + Math.cos(a0) * d0, cy + Math.sin(a0) * d0, 4 + r() * 8, 1, r() < 0.5 ? '#5a3318' : '#8a5a2e'); }
    // magic ring + sparkles of the emblem
    var a, rr = Math.min(48, sr - 6);
    for (a = 0; a < 360; a += 3) { var qx = Math.round(cx + Math.cos(a * Math.PI / 180) * rr), qy = Math.round(cy + Math.sin(a * Math.PI / 180) * rr * 0.9); g.fillStyle = (a % 30 === 0) ? 'rgba(240,192,64,0.85)' : 'rgba(255,230,160,0.2)'; g.fillRect(qx, qy, 1, 1); }
    [0, 90, 180, 270].forEach(function (aa) { diamond(g, Math.round(cx + Math.cos(aa * Math.PI / 180) * rr), Math.round(cy + Math.sin(aa * Math.PI / 180) * rr * 0.9), P.gold2); });
    // gems on the golden rim
    for (a = 0; a < 360; a += 45) gem(g, Math.round(cx + Math.cos(a * Math.PI / 180) * (rt - 8)), Math.round(cy + Math.sin(a * Math.PI / 180) * (rt - 8)), a % 90 === 0 ? '#ff5a6e' : '#4aa3ff');
    // candle + lantern (static parts)
    candleBody(g, 7, 22); candleBody(g, W - 9, H - 53); lantern(g, W - 7, Math.round(H * 0.43));
    roundInfo = { wx: wx, wy: wy, ww: ww, wh: wh, lights: [
      { x: 7, y: 19, r: 38, rgb: '255,150,50', seed: 4, a: 0.62, kind: 'candle', fy: 22 },
      { x: W - 9, y: H - 56, r: 40, rgb: '255,150,50', seed: 5, a: 0.62, kind: 'candle', fy: H - 53 },
      { x: W - 7, y: Math.round(H * 0.43) + 6, r: 28, rgb: '255,170,60', seed: 6, a: 0.5, kind: 'lantern' }
    ] };
    roundCache = c; roundKey = W + 'x' + H + ':' + G.diceCY;
  }

  // 0..1 lightning strength at time `now`; most 7-second windows contain a flash, some do not
  function lightning(now) {
    if (G.flashDebug !== undefined) return G.flashDebug;
    var per = Math.floor(now / 7000), ph = now % 7000;
    if (hash(per * 3 + 1) > 0.72) return 0;
    var d = ph - (900 + hash(per) * 4400);
    if (d < 0 || d > 560) return 0;
    if (d < 70) return 1; if (d < 140) return 0.12; if (d < 240) return 0.85;
    return Math.max(0, 0.55 * (1 - (d - 240) / 320));
  }
  function bolt(x, y, seed) {
    var i, px = x, py = y, r = rng(seed);
    for (i = 0; i < 18; i++) {
      var nx = px + Math.round((r() - 0.45) * 5), ny = py + 2 + Math.floor(r() * 2);
      rect(ctx, Math.min(px, nx), py, Math.abs(nx - px) + 1, ny - py + 1, '#ffffff');
      if (i % 5 === 3) rect(ctx, nx, ny, 3 + Math.floor(r() * 3) * (r() < 0.5 ? 1 : -1), 1, '#cfe2ff');
      px = nx; py = ny;
    }
  }

  G.tableRound = function (now) {
    var key = G.W + 'x' + G.H + ':' + G.diceCY;
    if (!roundCache || roundKey !== key) buildRound();
    ctx.drawImage(roundCache, 0, 0);
    var W = G.W, H = G.H, I = roundInfo, i, L, f = lightning(now);
    // rain behind the window panes
    var rx, ry;
    ctx.save(); ctx.beginPath(); ctx.rect(I.wx, I.wy + 3, I.ww - 8, I.wh - 2); ctx.clip();
    ctx.fillStyle = 'rgba(160,200,255,0.55)';
    for (i = 0; i < 16; i++) { rx = I.wx + 2 + ((i * 11 + 3) % (I.ww - 10)); ry = I.wy + 3 + ((now / 28 + i * 17) % (I.wh + 4)); ctx.fillRect(Math.round(rx), Math.round(ry), 1, 3); }
    if (f > 0.05) { ctx.fillStyle = 'rgba(210,225,255,' + (0.7 * f) + ')'; ctx.fillRect(I.wx, I.wy + 3, I.ww, I.wh); }
    ctx.restore();
    if (f > 0.5) bolt(I.wx + 14 + Math.floor(hash(Math.floor(now / 7000)) * 12), I.wy + 4, Math.floor(now / 7000) + 7);
    for (i = 0; i < I.lights.length; i++) {
      L = I.lights[i];
      glow(L.x, L.y, L.r, L.rgb, L.a * flicker(now, L.seed));
      if (L.kind === 'candle') flame(L.x, L.fy, now, L.seed); else glow(L.x, L.y, 8, '255,220,120', 0.55 * flicker(now, L.seed + 3));
    }
    if (f > 0.02) {                                    // the flash floods the room from the window
      var wcx = I.wx + (I.ww >> 1), wcy = I.wy + (I.wh >> 1);
      glow(wcx, wcy, 150, '150,185,255', 0.55 * f);
      glow(wcx, wcy, 60, '230,240,255', 0.55 * f);
      ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.fillStyle = 'rgba(70,90,160,' + (0.16 * f) + ')'; ctx.fillRect(0, 0, W, H); ctx.restore();
    }
  };
  G.invalidateScenes = function () { rectCache = null; roundCache = null; };
})();
