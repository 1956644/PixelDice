/* Pixel Dice - main.js : screens, input, game rendering, networking glue
 * Credit: Hirkan
 */
(function () {
  'use strict';
  var DD = window.DD, G = window.G, P = G.P, ctx = G.ctx;
  var PORT = DD.C.PORT;
  var native = window.Native || null;

  /* ------------------------------------------------------------ storage */
  function lsGet(k, d) { try { var v = localStorage.getItem(k); return v === null ? d : v; } catch (e) { return d; } }
  function lsSet(k, v) { try { localStorage.setItem(k, String(v)); } catch (e) { } }

  var app = window.APP = {
    screen: 'menu', name: lsGet('pd_name', ''), xp: parseInt(lsGet('pd_xp', '0'), 10) || 0,
    skin: parseInt(lsGet('pd_skin', '0'), 10) || 0, dialog: null, gs: null, snap: null, lastAward: '', award: null,
    anim: { rollId: -1, t0: 0, mask: [false, false, false, false, false] }, net: null, toast: null
  };
  function level() { return DD.levelFromXp(app.xp); }
  if (app.skin >= level()) app.skin = 0;
  function save() { lsSet('pd_name', app.name); lsSet('pd_xp', app.xp); lsSet('pd_skin', app.skin); }

  /* -------------------------------------------------------------- texts */
  var RULES = [
    '۵ تاس داریم. هر نوبت دو بار می‌تونی تاس بندازی؛ بار دوم فقط تاس‌هایی که انتخابشون نکردی دوباره ریخته میشن.',
    'روی تاس‌ها بزن: قاب طلایی یعنی حساب میشه، تاس تیره یعنی دوباره پرتاب میشه.',
    'امتیاز = جمع تاس‌های انتخابی × تعداد تاس‌های جفت. مثلاً ۲ و ۲ یعنی دو تاس جفت، ۳ و ۳ هم دو تا، ۴ و ۴ و ۴ سه تا.',
    'بالای صفحه امتیاز هدف هر دست نوشته شده؛ هر کی زودتر بهش برسه برنده‌ی دسته. هر دست ۱۰۰ امتیاز به هدف اضافه میشه.',
    'ترکیب‌های افسانه‌ای (پایین‌تر) امتیاز جایزه دارن و به امتیاز عادی اضافه میشن. فقط بهترین ترکیب حساب میشه و تاس‌های ترکیب باید انتخاب شده باشن.',
    'هر کی ۳ دست ببره، برنده‌ی بازیه.',
    'بازی دو و سه نفره بدون اینترنت و با هات‌اسپات انجام میشه.'
  ];

  /* ------------------------------------------------------- name overlay */
  var nameBox = document.getElementById('nameBox'), nameIn = document.getElementById('nameIn');
  var nameForced = false;
  function openName(forced) {
    nameForced = !!forced;
    document.getElementById('nameTitle').textContent = forced ? 'اسمت چیه؟' : 'ویرایش اسم';
    document.getElementById('nameCancel').style.display = forced ? 'none' : 'block';
    nameIn.value = app.name; nameBox.style.display = 'flex';
    setTimeout(function () { try { nameIn.focus(); nameIn.select(); } catch (e) { } }, 60);
  }
  function closeName() { nameBox.style.display = 'none'; nameIn.blur(); }
  function commitName() {
    var v = nameIn.value.replace(/\s+/g, ' ').trim().slice(0, 12);
    if (!v) { nameIn.style.borderColor = '#d6344a'; return; }
    nameIn.style.borderColor = '#241608';
    app.name = v; save(); closeName(); G.clearTextCache();
  }
  document.getElementById('nameOk').addEventListener('click', commitName);
  document.getElementById('nameCancel').addEventListener('click', function () { if (!nameForced) closeName(); });
  nameIn.addEventListener('keydown', function (e) { if (e.key === 'Enter') commitName(); });

  /* --------------------------------------------------------- native I/O */
  window.NativeEvent = function (kind, id, data) {
    var s = app.gs && (app.gs.host || app.gs.guest);
    if (s) s.onEvent(kind, id, data);
  };
  var hostTx = {
    sendTo: function (id, str) { if (native) native.sendTo(id, str); },
    sendAll: function (str) { if (native) native.sendAll(str); },
    drop: function (id) { if (native) native.drop(id); }
  };
  var guestTx = { sendHost: function (str) { if (native) native.sendToHost(str); } };

  /* ------------------------------------------------------------ sessions */
  function endSession() {
    var g = app.gs;
    if (g) {
      if (g.ctrl) g.ctrl.stop();
      if (g.host) g.host.close();
      if (g.guest) g.guest.close();
    }
    if (native) { try { native.stopAll(); } catch (e) { } }
    app.gs = null; app.snap = null; app.net = null; app.lastAward = ''; app.award = null;
  }
  function toMenu(msg) {
    endSession(); app.screen = 'menu'; app.dialog = null;
    if (msg) showDialog({ lines: msg, buttons: [{ t: 'باشه', style: 'gold' }] });
  }
  function setSnap(s) { app.snap = s; onSnap(s); }

  function startBot() {
    endSession();
    var gs = app.gs = { mode: 'bot', me: 0, n: 2 };
    gs.ctrl = new DD.Controller({
      n: 2, names: [app.name, 'BOT'], skins: [app.skin, 1 + Math.floor(Math.random() * Math.max(1, Math.min(level(), 7) - 0))], bots: [false, true], onChange: setSnap
    });
    gs.act = function (a) { return gs.ctrl.act(0, a); };
    app.screen = 'game'; gs.ctrl.start();
  }
  function startLocalBots(n) {   // debug / screenshots: bots play every seat
    endSession();
    var names = ['YOU', 'ALI', 'SARA'].slice(0, n), gs = app.gs = { mode: 'bot', me: 0, n: n };
    gs.ctrl = new DD.Controller({ n: n, names: names, skins: [app.skin, 1, 3], bots: names.map(function (x, i) { return i > 0; }), onChange: setSnap });
    gs.act = function (a) { return gs.ctrl.act(0, a); };
    app.screen = 'game'; gs.ctrl.start();
  }

  function startHost(n) {
    endSession();
    var gs = app.gs = { mode: 'host', me: 0, n: n, lobby: null };
    app.net = { role: 'host', n: n, status: 'wait' };
    gs.host = new DD.HostSession(hostTx, { n: n, name: app.name, skin: app.skin }, {
      onLobby: function (l) { gs.lobby = l; },
      onStart: function () { app.screen = 'game'; },
      onState: setSnap,
      onEnd: function () { toMenu(['یکی از بازیکن‌ها از بازی رفت.', 'اتصال قطع شد.']); }
    });
    gs.lobby = gs.host.lobby();
    gs.act = function (a) { return gs.host.act(a); };
    app.screen = 'lobby';
    if (native) native.startServer(PORT);
  }
  function startGuest(n) {
    endSession();
    var gs = app.gs = { mode: 'guest', me: -1, n: n, lobby: null };
    app.net = { role: 'guest', n: n, status: 'connecting', err: '' };
    gs.guest = new DD.GuestSession(guestTx, { name: app.name, skin: app.skin }, {
      onConnected: function () { app.net.status = 'hello'; },
      onWelcome: function (seat, nn) { gs.me = seat; gs.n = nn; app.net.status = 'lobby'; },
      onLobby: function (l) { gs.lobby = l; app.net.status = 'lobby'; },
      onStart: function () { app.screen = 'game'; },
      onState: setSnap,
      onError: function (e) { app.net.status = 'error'; app.net.err = String(e || ''); },
      onEnd: function () { toMenu(['ارتباط با میزبان قطع شد.']); }
    });
    gs.act = function (a) { return gs.guest.act(a); };
    app.screen = 'lobby';
    if (native) native.connect(PORT); else { app.net.status = 'error'; app.net.err = 'no-native'; }
  }

  /* ---------------------------------------------------------------- xp */
  function onSnap(s) {
    var gs = app.gs; if (!gs) return;
    var me = gs.me;
    if (s.id !== app.snapId) { app.snapId = s.id; app.lastAward = ''; app.award = null; }
    if (s.phase === 'hand_over' || s.phase === 'match_over') {
      var key = s.id + ':' + s.hand;
      if (app.lastAward !== key) {
        app.lastAward = key;
        var before = level(), gain = 10;
        if (s.handWinner === me) gain += 25;
        if (s.phase === 'match_over' && s.matchWinner === me) gain += 40;
        app.xp += gain; save();
        var after = level();
        app.award = { gain: gain, up: after > before ? after : 0, key: key };
      }
    }
  }

  /* ------------------------------------------------------------- dialog */
  function showDialog(d) { app.dialog = d; }
  function drawDialog() {
    var d = app.dialog; if (!d) return;
    G.regions = [];
    ctx.fillStyle = 'rgba(8,4,0,0.72)'; ctx.fillRect(0, 0, G.W, G.H);
    var pw = Math.min(G.W - 20, 164), size = 9, lines = [], i;
    for (i = 0; i < d.lines.length; i++) lines = lines.concat(G.wrap(d.lines[i], size, pw - 20));
    var bh = 20, gap = 5, ph = 22 + lines.length * 13 + 12 + d.buttons.length * (bh + gap) + 4;
    var px = (G.W - pw) >> 1, py = Math.max(10, ((G.H - ph) >> 1) - 10);
    G.panel(px, py, pw, ph, 'parch');
    for (i = 0; i < lines.length; i++) G.text(lines[i], G.W >> 1, py + 12 + i * 13, { c: P.ink, size: size, a: 'c', bold: i === 0 && d.title });
    var by = py + 22 + lines.length * 13 + 4;
    d.buttons.forEach(function (b, k) {
      G.button('dlg' + k, px + 12, by + k * (bh + gap), pw - 24, bh, b.t, {
        style: b.style || 'gold', modal: true, cb: function () { app.dialog = null; if (b.cb) b.cb(); }
      });
    });
  }

  /* ---------------------------------------------------------- utilities */
  function fitSys(str, maxW, size, bold) { return G.fit(str, maxW, { size: size, bold: bold }); }
  function drawCorner() {
    // top-left: name + edit
    var nm = fitSys(app.name || '...', 74, 9, true), w = Math.max(40, G.textW(nm, { size: 9, bold: true }) + 22), x = 3, y = 3, h = 17;
    G.panel(x, y, w, h, 'dark');
    G.sprite('pencil', x + 4, y + 4, 1);
    G.text(nm, x + 15, y + 2, { c: P.gold3, size: 9, bold: true });
    G.region('editName', x, y, w, h, function () { openName(false); });
  }

  var rulesCv = null, rulesKey = '';
  var COMBO_EX = { king6: [6, 6, 6, 6, 6], five: [3, 3, 3, 3, 3], dragon: [1, 1, 6, 6, 6], phoenix: [5, 5, 2, 2, 2], straight: [1, 2, 3, 4, 5], four: [4, 4, 4, 4], house: [3, 3, 4, 4, 4], parity: [1, 3, 3, 5, 5] };
  function rulesCanvas(w) {
    if (rulesCv && rulesKey === w) return rulesCv;
    var size = 8, lh = 12, maxW = w - 18, lines = [], i;
    RULES.forEach(function (r) { G.wrap(r, size, maxW).forEach(function (l, j) { lines.push({ t: l, b: j === 0 }); }); });
    var order = DD.COMBO_ORDER, rowH = 15;
    var h = 4 + lines.length * lh + 8 + 15 + order.length * rowH + 4;
    var c = G.mkHi(w, h), g = c.getContext('2d'), y = 4;
    for (i = 0; i < lines.length; i++) {
      G.text(lines[i].t, w - 8, y + i * lh, { c: P.ink, size: size, a: 'r' }, g);
      if (lines[i].b) { g.fillStyle = P.redD; g.fillRect(w - 5, y + i * lh + 4, 2, 2); }
    }
    y += lines.length * lh + 6;
    g.fillStyle = P.parch3; g.fillRect(4, y, w - 12, 1); y += 4;
    G.text('ترکیب‌های افسانه‌ای', w - 8, y, { c: P.redD, size: 10, a: 'r', bold: true }, g); y += 15;
    order.forEach(function (id, k) {
      var ex = COMBO_EX[id], cb = DD.COMBOS[id], yy = y + k * rowH, j;
      if (k % 2 === 0) { g.fillStyle = 'rgba(184,154,96,0.22)'; g.fillRect(2, yy - 1, w - 8, rowH - 1); }
      for (j = 0; j < ex.length; j++) G.die(4 + j * 11, yy + 1, 10, 10, ex[j], 0, 0, { flat: true }, g);
      G.text('+' + cb.bonus, 62, yy + 3, { c: P.greenD, s: 1 }, g);
      G.text(cb.name, w - 8, yy, { c: P.ink, size: 9, a: 'r', bold: true }, g);
    });
    rulesCv = c; rulesKey = w; return c;
  }

  /* --------------------------------------------------------------- menu */
  function drawMenu(now) {
    G.table(now);
    var W = G.W, H = G.H, R = G.TR;
    drawCorner();
    // level / dice button (top-right)
    var lv = level(), lw = 44, lx = W - lw - 3;
    G.panel(lx, 3, lw, 21, 'dark');
    G.sprite('star', lx + 4, 10, 1);
    G.text('LV ' + lv, lx + 15, 6, { c: P.gold2, s: 1 });
    G.text('DICE', lx + 15, 14, { c: P.cream, s: 1 });
    G.region('skins', lx, 3, lw, 21, function () { app.screen = 'skins'; });

    // title
    var ty = 26;
    G.text('PIXEL', W >> 1, ty, { c: P.gold2, s: 3, a: 'c', sh: '#3a2406' });
    G.text('DICE', W >> 1, ty + 25, { c: P.cream, s: 3, a: 'c', sh: '#3a2406' });
    var tw = 5 * 18 + 1;
    G.die(6 + 14, ty + 3, 14, 14, 5, 3, now, { idx: 1 });
    G.die(6 + 14, ty + 28, 14, 14, 2, 2, now, { idx: 3 });

    // buttons block (bottom), credit at the very bottom
    var bh = 22, gap = 5, bx = R + 10, bw = W - 2 * bx;
    var cy = H - 11;                   // credit sits on the floor strip below the table
    var by3 = H - 14 - 8 - bh;
    var by2 = by3 - gap - bh, by1 = by2 - gap - bh;
    // rules panel fills the room between title and buttons (drag / wheel to scroll)
    var ry = ty + 52, rh = by1 - 6 - ry, rx = R - 2, rw = W - 2 * rx;
    G.panel(rx, ry, rw, rh, 'parch');
    G.text('قوانین بازی', W >> 1, ry + 4, { c: P.redD, size: 10, a: 'c', bold: true });
    ctx.fillStyle = P.parch3; ctx.fillRect(rx + 8, ry + 19, rw - 16, 1);
    var vx = rx + 4, vy = ry + 22, vw = rw - 8, vh = rh - 26;
    var rc = rulesCanvas(vw);
    var maxS = Math.max(0, rc._h - vh), S = G.S, shown = Math.min(vh, rc._h);
    app.rulesY = Math.max(0, Math.min(maxS, app.rulesY || 0));
    app.rulesRect = { x: vx, y: vy, w: vw, h: vh, max: maxS };
    ctx.drawImage(rc, 0, Math.round(app.rulesY) * S, vw * S, shown * S, vx, vy, vw, shown);
    if (maxS > 0) {
      var tr = vh - 2, th = Math.max(8, Math.round(tr * vh / rc._h)), tyy = Math.round((tr - th) * app.rulesY / maxS);
      ctx.fillStyle = P.parch2; ctx.fillRect(vx + vw - 2, vy, 2, vh);
      ctx.fillStyle = P.redD; ctx.fillRect(vx + vw - 2, vy + tyy, 2, th);
      if (app.rulesY < maxS - 2 && Math.floor(now / 500) % 2) G.sprite('down', vx + (vw >> 1) - 3, vy + vh - 5, 1);
    }
    G.button('bot', bx, by1, bw, bh, 'بازی با بات', { style: 'green', size: 11, bold: true, cb: startBot });
    G.button('p2', bx, by2, bw, bh, 'بازی دونفره', { style: 'gold', size: 11, bold: true, cb: function () { askNet(2); } });
    G.button('p3', bx, by3, bw, bh, 'بازی سه نفره', { style: 'gold', size: 11, bold: true, cb: function () { askNet(3); } });
    G.text('Credit: Hirkan', W >> 1, cy, { c: P.gold1, s: 1, a: 'c', sh: '#000000' });
  }

  /* ------------------------------------------------------ network pick */
  function askNet(n) { app.netN = n; app.screen = 'netpick'; }
  function drawNetPick(now) {
    G.table(now);
    var W = G.W, H = G.H, R = G.TR, n = app.netN;
    drawCorner();
    G.text(n === 2 ? 'بازی دونفره' : 'بازی سه نفره', W >> 1, 28, { c: P.gold2, size: 12, a: 'c', bold: true, sh: '#3a2406' });
    var px = R - 2, pw = W - 2 * px, y = 50, bh = 22;
    function card(title, text, btn, style, cb, h) {
      G.panel(px, y, pw, h, 'parch');
      G.text(title, px + pw - 8, y + 6, { c: P.redD, size: 10, a: 'r', bold: true });
      var ls = G.wrap(text, 9, pw - 20), i;
      for (i = 0; i < ls.length; i++) G.text(ls[i], px + pw - 8, y + 23 + i * 13, { c: P.ink, size: 9, a: 'r' });
      G.button('nb' + title, px + 10, y + h - bh - 8, pw - 20, bh, btn, { style: style, size: 10, bold: true, cb: cb });
      y += h + 10;
    }
    card('میزبان باش', 'برای بازی با دوستان هات‌اسپات (نقطه اتصال) رو روشن کن تا دوستانت بهت وصل بشن.', 'من میزبانم', 'green', function () {
      showNetPermission('host');
    }, 118);
    card('وصل شو به دوستت', 'برای وصل شدن به دوستت وای‌فای رو روشن کن و به هات‌اسپات اون وصل شو.', 'من مهمانم', 'gold', function () {
      showNetPermission('guest');
    }, 118);
    G.button('back', R + 10, H - R - 8 - bh, W - 2 * (R + 10), bh, 'بازگشت', { style: 'wood', size: 10, bold: true, cb: function () { app.screen = 'menu'; } });
  }
  function showNetPermission(role) {
    var host = role === 'host', n = app.netN;
    showDialog({
      title: true,
      lines: host ? ['اجازه‌ی تنظیمات اتصال', 'بازی اجازه می‌خواد تنظیمات هات‌اسپات (نقطه اتصال) رو برات باز کنه. هات‌اسپات رو روشن کن و برگرد به بازی.']
        : ['اجازه‌ی تنظیمات اتصال', 'بازی اجازه می‌خواد تنظیمات وای‌فای رو برات باز کنه. وای‌فای رو روشن کن، به هات‌اسپات دوستت وصل شو و برگرد به بازی.'],
      buttons: [{
        t: 'اجازه میدم', style: 'green', cb: function () {
          if (native) { try { native.openSettings(host ? 'hotspot' : 'wifi'); } catch (e) { } }
          if (host) startHost(n); else startGuest(n);
        }
      }, { t: 'لغو', style: 'red' }]
    });
  }

  /* -------------------------------------------------------------- lobby */
  function drawLobby(now) {
    G.table(now);
    var W = G.W, H = G.H, R = G.TR, net = app.net, gs = app.gs; if (!net || !gs) return;
    var n = net.n, host = net.role === 'host', px = R - 2, pw = W - 2 * px, bh = 22, i;
    drawCorner();
    G.text(host ? 'میزبان' : 'مهمان', W >> 1, 28, { c: P.gold2, size: 12, a: 'c', bold: true, sh: '#3a2406' });
    var y = 50, h = 56;
    G.panel(px, y, pw, h, 'parch');
    var msg;
    if (host) msg = ['هات‌اسپات روشنه؟ دوستات باید بهش وصل بشن و بعد خودکار وارد این صفحه میشن.'];
    else if (net.status === 'connecting') msg = ['در حال اتصال به دوستت... مطمئن شو به هات‌اسپات اون وصل هستی.'];
    else if (net.status === 'error') msg = ['وصل نشد. مطمئن شو به هات‌اسپات دوستت وصل هستی و دوستت صفحه‌ی میزبان رو باز کرده.'];
    else if (net.status === 'hello') msg = ['وصل شدیم! در حال تایید اسم‌ها...'];
    else msg = ['اتصال برقرار شد. منتظر بقیه...'];
    var ls = G.wrap(msg[0], 9, pw - 18);
    for (i = 0; i < ls.length; i++) G.text(ls[i], px + pw - 8, y + 6 + i * 13, { c: P.ink, size: 9, a: 'r' });
    y += h + 8;
    var lobby = gs.lobby || { names: [], ok: [] };
    G.panel(px, y, pw, 18 + n * 24, 'dark');
    G.text('بازیکن‌ها', px + pw - 8, y + 4, { c: P.gold2, size: 9, a: 'r', bold: true });
    for (i = 0; i < n; i++) {
      var yy = y + 20 + i * 24, ok = lobby.ok && lobby.ok[i], nm = lobby.names && lobby.names[i];
      ctx.fillStyle = 'rgba(255,255,255,0.07)'; ctx.fillRect(px + 5, yy, pw - 10, 20);
      G.text(ok ? fitSys(nm, pw - 50, 10, true) : '...', px + pw - 10, yy + 3, { c: ok ? P.cream : '#8a7a5a', size: 10, a: 'r', bold: ok });
      if (ok) G.sprite('check', px + 9, yy + 6, 2); else G.sprite('cross', px + 9, yy + 7, 2);
      if (ok && i === (gs.me < 0 ? 0 : gs.me) && !host) G.text('(تو)', px + 26, yy + 4, { c: P.gold2, size: 8 });
      if (ok && host && i === 0) G.text('(تو)', px + 26, yy + 4, { c: P.gold2, size: 8 });
    }
    y += 18 + n * 24 + 8;
    var full = lobby.full;
    G.text(full ? 'همه‌ی اسم‌ها تایید شد! بازی شروع میشه...' : 'منتظر تایید اسم همه‌ی بازیکن‌ها', W >> 1, y, { c: full ? '#4cff8a' : P.gold3, size: 9, a: 'c', sh: '#000' });
    var bw = W - 2 * (R + 10), by = H - R - 8 - bh;
    if (!host && (net.status === 'error')) {
      G.button('retry', R + 10, by - bh - 6, bw, bh, 'تلاش دوباره', { style: 'green', size: 10, bold: true, cb: function () { startGuest(n); } });
      G.button('wifi', R + 10, by - 2 * (bh + 6), bw, bh, 'باز کردن تنظیمات وای‌فای', { style: 'gold', size: 9, bold: true, cb: function () { if (native) native.openSettings('wifi'); } });
    } else if (host) {
      G.button('hs', R + 10, by - bh - 6, bw, bh, 'باز کردن تنظیمات هات‌اسپات', { style: 'gold', size: 9, bold: true, cb: function () { if (native) native.openSettings('hotspot'); } });
    }
    G.button('cancel', R + 10, by, bw, bh, 'لغو و بازگشت', { style: 'red', size: 10, bold: true, cb: function () { toMenu(); } });
  }

  /* -------------------------------------------------------------- skins */
  function drawSkins(now) {
    G.table(now);
    var W = G.W, H = G.H, R = G.TR, lv = level(), i;
    drawCorner();
    G.text('تاس‌های فانتزی', W >> 1, 26, { c: P.gold2, size: 12, a: 'c', bold: true, sh: '#3a2406' });
    var next = DD.LEVEL_XP[lv] !== undefined ? DD.LEVEL_XP[lv] : null;
    G.text('LEVEL ' + lv + '   XP ' + app.xp + (next ? ' / ' + next : ' MAX'), W >> 1, 44, { c: P.cream, s: 1, a: 'c', sh: '#000' });
    var px = R - 2, pw = W - 2 * px, cols = 2, cw = ((pw - 10) / cols) | 0, ch = 62, x0 = px + 5, y0 = 58;
    for (i = 0; i < 8; i++) {
      var cx = x0 + (i % cols) * (cw + 0), cy = y0 + ((i / cols) | 0) * (ch + 4);
      var unlocked = i < lv, sel = app.skin === i;
      G.panel(cx + 1, cy, cw - 2, ch, sel ? 'wood' : 'dark');
      if (sel) { ctx.fillStyle = P.gold2; ctx.fillRect(cx + 1, cy, cw - 2, 1); ctx.fillRect(cx + 1, cy + ch - 1, cw - 2, 1); }
      var ds = 26, dx = cx + ((cw - ds) >> 1), dy = cy + 6;
      G.die(dx, dy, ds, ds, ((i * 2 + 1) % 6) + 1, i, now, { idx: i });
      if (!unlocked) { ctx.fillStyle = 'rgba(10,5,0,0.7)'; ctx.fillRect(dx - 1, dy - 1, ds + 2, ds + 3); G.sprite('lock', dx + 7, dy + 6, 2); }
      G.text(DD.SKIN_NAMES[i], cx + (cw >> 1), cy + 37, { c: unlocked ? P.gold3 : '#8a7a5a', s: 1, a: 'c' });
      G.text(unlocked ? (sel ? 'SELECTED' : 'TAP') : 'LEVEL ' + (i + 1), cx + (cw >> 1), cy + 48, { c: unlocked ? (sel ? '#4cff8a' : P.cream) : '#8a7a5a', s: 1, a: 'c' });
      if (unlocked) (function (k) { G.region('sk' + k, cx, cy, cw, ch, function () { app.skin = k; save(); }); })(i);
    }
    var bh = 22;
    G.button('back', R + 10, H - R - 8 - bh, W - 2 * (R + 10), bh, 'بازگشت', { style: 'wood', size: 10, bold: true, cb: function () { app.screen = 'menu'; } });
  }

  /* --------------------------------------------------------------- game */
  function seatsLayout(s, me) {
    if (s.n === 2) return { bottom: me, top: (me + 1) % 2 };
    return { bottom: me, left: (me + 1) % 3, right: (me + 2) % 3 };
  }
  function plaqueDraw(i, s, now, x, y, w, rot) {
    var h = 28, pc = G.mkHi(w, h), g = pc.getContext('2d');
    G.plaque(g, w, h, s.names[i], s.totals[i], s.wins[i], { active: s.turn === i && s.phase !== 'hand_over' && s.phase !== 'match_over', now: now });
    if (!rot) { ctx.drawImage(pc, Math.round(x), Math.round(y), w, h); return; }
    ctx.save(); ctx.translate(Math.round(x), Math.round(y)); ctx.rotate(rot * Math.PI / 2);
    ctx.drawImage(pc, rot > 0 ? 0 : -w, rot > 0 ? -h : 0, w, h); ctx.restore();
  }

  function dieGeom(avail) {
    var dw = Math.max(18, Math.min(30, Math.floor((avail - 24) / 5.5))), gap = Math.max(3, Math.floor(dw * 0.2));
    var total = dw * 5 + gap * 4;
    return { dw: dw, gap: gap, x0: Math.round((G.W - total) / 2) };
  }

  function drawGame(now) {
    var s = app.snap, gs = app.gs, W = G.W, H = G.H, R = G.TR, i;
    if (s && s.n === 3) G.tableRound(now); else G.table(now);
    if (!s) { G.text('...', W >> 1, H >> 1, { c: P.cream, size: 10, a: 'c' }); return; }
    var me = gs.me < 0 ? 0 : gs.me, lay = seatsLayout(s, me);

    // --- header: goal of the hand
    var bw = Math.min(W - 84, 100), bx = (W - bw) >> 1, by = R + 3;
    G.panel(bx, by, bw, 25, 'dark');
    G.text('هدف دست ' + G.fa(s.hand), W >> 1, by + 2, { c: P.cream, size: 8, a: 'c' });
    G.text(String(s.target), W >> 1, by + 11, { c: P.gold2, s: 2, a: 'c', sh: '#000' });
    // exit button (top-left, inside rail corner)
    G.button('exit', R + 2, by, 22, 25, 'X', { style: 'red', s: 2, cb: function () {
      showDialog({ lines: ['از بازی خارج میشی؟'], buttons: [{ t: 'بله، خروج', style: 'red', cb: function () { toMenu(); } }, { t: 'ادامه‌ی بازی', style: 'green' }] });
    } });

    // --- plaques
    var cy = G.diceCY, pw2 = Math.min(W - 60, 112);
    if (s.n === 2) plaqueDraw(lay.top, s, now, (W - pw2) >> 1, by + 32, pw2, 0);
    else {
      var sh = 84, sy = Math.round(by + 30 + 6);
      plaqueDraw(lay.left, s, now, R + 4, sy, sh, 1);                 // rotated clockwise: reads top-to-bottom
      plaqueDraw(lay.right, s, now, W - R - 4 - 28, sy, sh, -1);      // rotated counter-clockwise
    }
    var bh = 22, btnY = H - R - 5 - bh;
    plaqueDraw(lay.bottom, s, now, (W - pw2) >> 1, btnY - 34, pw2, 0);

    // --- dice
    var geom = dieGeom(s.n === 3 ? 150 : W - 16), dw = geom.dw, dy = cy - (dw >> 1), turnSkin = s.skins[s.turn] || 0;
    if (s.rollId !== app.anim.rollId) { app.anim = { rollId: s.rollId, t0: now, mask: s.rolled.slice() }; }
    var el = now - app.anim.t0, myTurn = s.turn === me && !(gs.mode === 'guest' && gs.me < 0);
    var canPick = myTurn && s.phase === 'await_action';
    var rnd = G.rng(Math.floor(el / 70) * 13 + s.rollId * 7);
    var turnName = s.names[s.turn];
    var tl = (s.phase === 'hand_over' || s.phase === 'match_over') ? '' : (myTurn ? 'نوبت توئه!' : 'نوبت ' + turnName);
    if (tl) G.text(fitSys(tl, W - 30, 10, true), W >> 1, cy - dw - 26, { c: myTurn ? P.gold2 : P.cream, size: 10, a: 'c', bold: true, sh: '#000' });
    for (i = 0; i < 5; i++) {
      var x = geom.x0 + i * (dw + geom.gap), y = dy, v = s.dice[i], rolling = false;
      if (app.anim.mask[i]) {
        var dur = 480 + i * 90;
        if (el < dur) {
          rolling = true; v = 1 + Math.floor(rnd() * 6) + 0 * i; rnd();
          var ph = el / dur, bounce = Math.abs(Math.sin(ph * Math.PI * 3.2)) * (1 - ph) * 22;
          y = dy - Math.round(bounce); x += Math.round((rnd() - 0.5) * 6 * (1 - ph));
        }
      }
      var showSel = s.phase === 'await_action' && s.rolls >= 1 && !rolling;
      G.die(x, y, dw, dw, v, turnSkin, now, { idx: i, gold: showSel && s.sel[i], dim: showSel && !s.sel[i] });
      if (canPick && !rolling) (function (k, xx) { G.region('d' + k, xx - 2, dy - 4, dw + 4, dw + 8, function () { gs.act({ a: 'toggle', i: k }); }); })(i, x);
    }

    // --- info line under dice
    var iy = cy + dw + 6;
    if (s.phase === 'await_action') {
      var b = DD.breakdown(s.dice, s.sel);
      var animating = el < 480 + 4 * 90 + 80;
      if (!animating) {
        G.text('جمع ' + b.sum + '  ×  جفت ' + b.pairs, W >> 1, iy, { c: P.cream, size: 9, a: 'c', sh: '#000' });
        G.text('= ' + b.score, W >> 1, iy + 14, { c: b.score ? P.gold2 : '#ff8a8a', s: 3, a: 'c', sh: '#000' });
        if (b.combo) comboBanner(b.combo, b.bonus, W >> 1, iy + 40, now);
      }
    } else if (s.phase === 'scored' && s.last) {
      var pulse = 1 + (Math.floor(now / 140) % 2);
      G.text('+' + s.last.score, W >> 1, iy + 2, { c: s.last.score ? '#4cff8a' : '#ff8a8a', s: 3 + (pulse - 1), a: 'c', sh: '#000' });
      if (s.last.combo) comboBanner(s.last.combo, s.last.bonus, W >> 1, iy + 34, now);
    }

    // --- buttons (only for the player whose turn it is)
    var bw2 = W - 2 * (R + 8);
    if (myTurn && s.phase === 'await_roll') {
      G.button('roll', R + 8, btnY, bw2, bh, 'تاس بنداز', { style: 'gold', size: 12, bold: true, cb: function () { gs.act({ a: 'roll' }); } });
    } else if (myTurn && s.phase === 'await_action') {
      var hasFree = s.sel.some(function (x) { return !x; }), canRe = s.rolls < DD.C.MAX_ROLLS && hasFree;
      var hw = ((bw2 - 6) / 2) | 0, animNow = (now - app.anim.t0) < 480 + 4 * 90 + 80;
      var left = DD.C.MAX_ROLLS - s.rolls;
      G.button('reroll', R + 8, btnY, hw, bh, s.rolls < DD.C.MAX_ROLLS ? 'پرتاب دوباره' : 'پرتاب تموم شد', { style: 'gold', size: 9, bold: true, disabled: !canRe || animNow, cb: function () { gs.act({ a: 'reroll' }); } });
      G.button('submit', R + 8 + hw + 6, btnY, hw, bh, 'ثبت امتیاز', { style: 'green', size: 10, bold: true, disabled: animNow, cb: function () { gs.act({ a: 'submit' }); } });
      if (s.rolls < DD.C.MAX_ROLLS) {
        if (!hasFree) G.text('برای پرتاب دوباره یه تاس رو تیره کن', W >> 1, btnY - 11, { c: P.gold1, size: 8, a: 'c' });
        else G.text(left + ' پرتاب مونده', W >> 1, btnY - 11, { c: P.gold1, size: 8, a: 'c' });
      }
    } else if (s.phase === 'await_roll' || s.phase === 'await_action') {
      G.text(fitSys('منتظر ' + turnName + '...', W - 30, 9), W >> 1, btnY + 6, { c: P.cream, size: 9, a: 'c', sh: '#000' });
    }

    // --- overlays
    if (s.phase === 'hand_over') drawHandOver(s, me, now);
    else if (s.phase === 'match_over') drawMatchOver(s, me, now, gs);
  }

  function comboBanner(id, bonus, x, y, now) {
    var cb = DD.COMBOS[id], on = Math.floor(now / 160) % 2, t = cb.name + '  \u200E+' + bonus;
    var w = G.textW(t, { size: 10, bold: true }) + 14;
    G.panel(x - (w >> 1), y - 2, w, 17, 'dark');
    G.text(t, x, y, { c: on ? P.gold3 : P.gold2, size: 10, a: 'c', bold: true });
    var k; for (k = 0; k < 4; k++) { var ph = (now / 220 + k * 1.7) % 6.28, sx = x - (w >> 1) + 3 + Math.round((0.5 + 0.5 * Math.sin(ph + k)) * (w - 6)); ctx.fillStyle = 'rgba(255,255,220,0.9)'; ctx.fillRect(sx, y - 3 + (k % 2) * 17, 1, 1); }
  }
  function awardLines() {
    var a = app.award, out = [];
    if (!a) return out;
    out.push('+' + a.gain + ' XP');
    if (a.up) out.push('لول ' + G.fa(a.up) + '! یه تاس فانتزی جدید باز شد');
    return out;
  }
  function drawHandOver(s, me, now) {
    var W = G.W, H = G.H, pw = Math.min(W - 24, 150), ph = 96, px = (W - pw) >> 1, py = ((H - ph) >> 1) - 20;
    G.regions = G.regions.filter(function (r) { return false; });
    ctx.fillStyle = 'rgba(8,4,0,0.55)'; ctx.fillRect(0, 0, W, H);
    G.panel(px, py, pw, ph, 'parch');
    G.text('دست ' + G.fa(s.hand) + ' تموم شد', W >> 1, py + 6, { c: P.redD, size: 10, a: 'c', bold: true });
    G.text(fitSys(s.names[s.handWinner], pw - 16, 11, true), W >> 1, py + 24, { c: P.ink, size: 11, a: 'c', bold: true });
    G.text(s.handWinner === me ? 'تو بردی!' : 'برنده‌ی این دست', W >> 1, py + 40, { c: s.handWinner === me ? P.greenD : P.ink, size: 9, a: 'c' });
    for (var i = 0; i < 3; i++) G.sprite(i < s.wins[s.handWinner] ? 'star' : 'starOff', (W >> 1) - 17 + i * 12 - 2, py + 55, 1);
    var al = awardLines();
    for (i = 0; i < al.length; i++) G.text(al[i], W >> 1, py + 69 + i * 11, { c: i === 0 ? P.greenD : P.redD, size: 8, a: 'c' });
    G.text('هدف دست بعد: ' + (s.target + DD.C.TARGET_STEP), W >> 1, py + ph - 14, { c: P.parch3, size: 8, a: 'c' });
  }
  function drawMatchOver(s, me, now, gs) {
    var W = G.W, H = G.H, pw = Math.min(W - 20, 160), ph = 168, px = (W - pw) >> 1, py = Math.max(30, ((H - ph) >> 1) - 20), i;
    G.regions = [];
    ctx.fillStyle = 'rgba(8,4,0,0.65)'; ctx.fillRect(0, 0, W, H);
    G.panel(px, py, pw, ph, 'parch');
    var won = s.matchWinner === me;
    G.sprite('cup', (W >> 1) - 9 + 0, py + 6 + Math.round(Math.sin(now / 200) * 1.5), 2);
    G.text(won ? 'تو برنده شدی!' : 'بازی تموم شد', W >> 1, py + 31, { c: won ? P.greenD : P.redD, size: 12, a: 'c', bold: true });
    G.text(fitSys('برنده: ' + s.names[s.matchWinner], pw - 14, 10, true), W >> 1, py + 49, { c: P.ink, size: 10, a: 'c', bold: true });
    for (i = 0; i < s.n; i++) {
      var yy = py + 66 + i * 12;
      G.text(fitSys(s.names[i], pw - 60, 9), px + pw - 10, yy, { c: P.ink, size: 9, a: 'r' });
      G.text(s.wins[i] + ' دست', px + 10, yy + 1, { c: P.ink, size: 8 });
    }
    var al = awardLines(), ay = py + 66 + s.n * 12 + 2;
    for (i = 0; i < al.length; i++) G.text(al[i], W >> 1, ay + i * 11, { c: i === 0 ? P.greenD : P.redD, size: 8, a: 'c' });
    var bh = 20, by = py + ph - 2 * bh - 14, bx = px + 10, bw = pw - 20;
    if (gs.mode === 'bot') G.button('again', bx, by, bw, bh, 'دوباره بازی کن', { style: 'green', size: 10, bold: true, cb: function () { app.lastAward = ''; if (gs.n === 2 && gs.ctrl.cfg.bots[1] && !gs.ctrl.cfg.bots[0]) startBot(); else startLocalBots(gs.n); } });
    else if (gs.mode === 'host') G.button('again', bx, by, bw, bh, 'بازی دوباره', { style: 'green', size: 10, bold: true, cb: function () { gs.host.rematch(); } });
    else G.text('منتظر میزبان برای بازی دوباره...', W >> 1, by + 5, { c: P.ink, size: 8, a: 'c' });
    G.button('menu', bx, by + bh + 6, bw, bh, 'منوی اصلی', { style: 'wood', size: 10, bold: true, cb: function () { toMenu(); } });
  }

  /* -------------------------------------------------------------- loop */
  function frame(now) {
    ctx.setTransform(G.S, 0, 0, G.S, 0, 0); ctx.imageSmoothingEnabled = false;
    G.regions = [];
    var sc = app.screen;
    if (sc === 'menu') drawMenu(now);
    else if (sc === 'netpick') drawNetPick(now);
    else if (sc === 'lobby') drawLobby(now);
    else if (sc === 'skins') drawSkins(now);
    else if (sc === 'game') drawGame(now);
    if (app.dialog) drawDialog();
    requestAnimationFrame(frame);
  }

  /* ------------------------------------------------------------- input */
  var down = null, drag = null;
  function inRules(p) { var q = app.rulesRect; return app.screen === 'menu' && !app.dialog && q && p.x >= q.x && p.x < q.x + q.w && p.y >= q.y && p.y < q.y + q.h; }
  G.cv.addEventListener('pointerdown', function (e) {
    e.preventDefault();
    if (nameBox.style.display === 'flex') return;
    var p = G.toLogical(e), r = G.hit(p.x, p.y);
    down = r; G.pressId = r ? r.id : null;
    drag = inRules(p) ? { y0: p.y, s0: app.rulesY || 0, moved: false } : null;
    try { G.cv.setPointerCapture(e.pointerId); } catch (x) { }
  });
  G.cv.addEventListener('pointermove', function (e) {
    if (!drag) return;
    var p = G.toLogical(e), dy = p.y - drag.y0;
    if (Math.abs(dy) > 2) drag.moved = true;
    if (drag.moved) app.rulesY = Math.max(0, Math.min(app.rulesRect.max, drag.s0 - dy));
  });
  G.cv.addEventListener('pointerup', function (e) {
    e.preventDefault();
    var p = G.toLogical(e), r = G.hit(p.x, p.y), d = down, moved = drag && drag.moved;
    down = null; drag = null; G.pressId = null;
    if (!moved && r && d && r.id === d.id && r.cb) r.cb();
  });
  G.cv.addEventListener('pointercancel', function () { down = null; drag = null; G.pressId = null; });
  G.cv.addEventListener('wheel', function (e) {
    var p = G.toLogical(e);
    if (inRules(p)) { app.rulesY = Math.max(0, Math.min(app.rulesRect.max, (app.rulesY || 0) + e.deltaY / G.K * 2)); e.preventDefault(); }
  }, { passive: false });
  document.addEventListener('contextmenu', function (e) { e.preventDefault(); });

  window.onBackPressed = function () {       // called by the Android back button
    if (nameBox.style.display === 'flex' && !nameForced) { closeName(); return true; }
    if (app.dialog) { app.dialog = null; return true; }
    if (app.screen === 'game') { showDialog({ lines: ['از بازی خارج میشی؟'], buttons: [{ t: 'بله، خروج', style: 'red', cb: function () { toMenu(); } }, { t: 'ادامه‌ی بازی', style: 'green' }] }); return true; }
    if (app.screen !== 'menu') { if (app.screen === 'lobby') toMenu(); else app.screen = 'menu'; return true; }
    return false;
  };

  G.onResize = function () { G.diceCY = Math.round(G.H * 0.5) - 4; };
  window.addEventListener('resize', G.resize);
  G.resize();

  // debug / automated screenshots:  index.html#bots2 | #bots3 | #skins | #menu
  var hash = (location.hash || '').replace('#', '');
  if (!app.name) { if (hash) { app.name = 'HIRKAN'; } else openName(true); }
  if (hash === 'bots2') startLocalBots(2);
  else if (hash === 'bots3') startLocalBots(3);
  else if (hash === 'skins') { app.xp = 99999; app.screen = 'skins'; }
  else if (hash === 'netpick') { app.netN = 2; app.screen = 'netpick'; }
  requestAnimationFrame(frame);
})();
