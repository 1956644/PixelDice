package com.hirkan.dicegame;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

/**
 * Pixel Dice - the whole game lives in assets/ (HTML + JS). This activity only hosts it in a WebView
 * and gives the page a small "Native" bridge for the hotspot (local Wi-Fi) multiplayer.
 * Credit: Hirkan
 */
public class MainActivity extends Activity {

    private WebView web;
    private GameNet net;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 28) {
            getWindow().getAttributes().layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }

        web = new WebView(this);
        web.setBackgroundColor(0xFF2A1408);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setVerticalScrollBarEnabled(false);
        web.setHorizontalScrollBarEnabled(false);
        web.setLongClickable(false);
        web.setHapticFeedbackEnabled(false);
        web.setOnLongClickListener(new View.OnLongClickListener() {
            public boolean onLongClick(View v) { return true; }
        });

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);          // keeps the player's name, level and dice choice
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setTextZoom(100);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.setWebViewClient(new WebViewClient());

        net = new GameNet(getApplicationContext(), new GameNet.Listener() {
            public void onEvent(final String kind, final int id, final String data) {
                runOnUiThread(new Runnable() {
                    public void run() { deliver(kind, id, data); }
                });
            }
        });
        web.addJavascriptInterface(new Bridge(), "Native");   // must be added before loadUrl

        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private void deliver(String kind, int id, String data) {
        if (web == null) return;
        String js = "window.NativeEvent&&window.NativeEvent(" + JSONObject.quote(kind) + "," + id + ","
                + (data == null ? "null" : JSONObject.quote(data)) + ")";
        web.evaluateJavascript(js, null);
    }

    /** Methods the page can call as window.Native.xxx(...). They run on a WebView background thread. */
    private final class Bridge {
        @JavascriptInterface public void startServer(int port) { net.startServer(port); }
        @JavascriptInterface public void connect(int port) { net.connect(port); }
        @JavascriptInterface public void sendTo(int id, String msg) { net.sendTo(id, msg); }
        @JavascriptInterface public void sendAll(String msg) { net.sendAll(msg); }
        @JavascriptInterface public void sendToHost(String msg) { net.sendToHost(msg); }
        @JavascriptInterface public void drop(int id) { net.drop(id); }
        @JavascriptInterface public void stopAll() { net.stopAll(); }
        @JavascriptInterface public void openSettings(final String kind) {
            runOnUiThread(new Runnable() {
                public void run() { openSettingsScreen("hotspot".equals(kind)); }
            });
        }
    }

    /**
     * Android does not let a normal app switch the hotspot on by itself, so we open the right
     * settings screen and the player flips the switch. Several screens are tried because phone
     * makers (Xiaomi, Samsung ...) name them differently.
     */
    private void openSettingsScreen(boolean hotspot) {
        Intent[] tries;
        if (hotspot) {
            tries = new Intent[]{
                    new Intent().setClassName("com.android.settings", "com.android.settings.TetherSettings"),
                    new Intent().setClassName("com.android.settings", "com.android.settings.Settings$TetherSettingsActivity"),
                    new Intent().setClassName("com.android.settings", "com.android.settings.wifi.tether.WifiTetherSettings"),
                    new Intent("android.settings.TETHER_SETTINGS"),
                    new Intent(Settings.ACTION_WIRELESS_SETTINGS),
                    new Intent(Settings.ACTION_SETTINGS)
            };
        } else {
            tries = new Intent[]{
                    new Intent(Settings.ACTION_WIFI_SETTINGS),
                    new Intent(Settings.ACTION_WIRELESS_SETTINGS),
                    new Intent(Settings.ACTION_SETTINGS)
            };
        }
        for (Intent i : tries) {
            try {
                startActivity(i);
                return;
            } catch (ActivityNotFoundException ignored) {
            } catch (SecurityException ignored) {
            } catch (RuntimeException ignored) {
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (web == null) { super.onBackPressed(); return; }
        web.evaluateJavascript("(window.onBackPressed&&window.onBackPressed())?'1':'0'", new ValueCallback<String>() {
            public void onReceiveValue(String v) {
                if (v == null || !v.contains("1")) finish();
            }
        });
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    @Override protected void onResume() { super.onResume(); if (web != null) web.onResume(); }
    @Override protected void onPause() { super.onPause(); if (web != null) web.onPause(); }

    @Override
    protected void onDestroy() {
        if (net != null) net.stopAll();
        if (web != null) { web.removeJavascriptInterface("Native"); web.destroy(); web = null; }
        super.onDestroy();
    }
}
