package com.hirkan.dicegame;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.DhcpInfo;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.wifi.WifiManager;
import android.os.Build;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Tiny LAN transport for the hotspot games. Messages are single lines of text (newline separated).
 *
 * Host side : listens on a TCP port; every friend that joins the hotspot connects here.
 * Guest side: connects to the hotspot owner (= the Wi-Fi gateway address).
 *
 * Events are delivered to the Listener on background threads: kind is one of
 *   client_in, client_out, msg   (host)      connected, disconnected, msg, error   (guest)
 * Credit: Hirkan
 */
final class GameNet {

    interface Listener { void onEvent(String kind, int id, String data); }

    private static final Charset UTF8 = Charset.forName("UTF-8");
    private static final String[] FALLBACK_HOSTS = {"192.168.43.1", "172.20.10.1", "192.168.49.1", "192.168.137.1"};

    private final Context ctx;
    private final Listener listener;
    private final Map<Integer, Peer> peers = new ConcurrentHashMap<Integer, Peer>();
    private volatile int gen = 0;            // bumps on every start/stop so stale threads quit quietly
    private ServerSocket server;
    private volatile Peer hostPeer;
    private int nextId = 1;

    GameNet(Context appContext, Listener l) {
        this.ctx = appContext;
        this.listener = l;
    }

    /* ----------------------------------------------------------------- peer */
    private final class Peer {
        final Socket socket;
        final int id;
        final ExecutorService writer = Executors.newSingleThreadExecutor();
        volatile boolean closed;

        Peer(Socket s, int id) { this.socket = s; this.id = id; }

        void send(final String msg) {
            if (closed) return;
            writer.execute(new Runnable() {
                public void run() {
                    try {
                        OutputStream os = socket.getOutputStream();
                        os.write((msg + "\n").getBytes(UTF8));
                        os.flush();
                    } catch (IOException e) {
                        close();
                    }
                }
            });
        }

        void close() {
            closed = true;
            try { socket.close(); } catch (IOException ignored) { }
            writer.shutdown();
        }
    }

    /* ----------------------------------------------------------------- host */
    void startServer(final int port) {
        stopAll();
        final int myGen = ++gen;
        final ServerSocket ss;
        try {
            ss = new ServerSocket();
            ss.setReuseAddress(true);
            ss.bind(new InetSocketAddress(port));
        } catch (IOException e) {
            emit(myGen, "error", 0, "bind: " + e.getMessage());
            return;
        }
        server = ss;
        new Thread(new Runnable() {
            public void run() {
                while (gen == myGen) {
                    try {
                        Socket c = ss.accept();
                        c.setTcpNoDelay(true);
                        c.setKeepAlive(true);
                        int id;
                        synchronized (GameNet.this) { id = nextId++; }
                        Peer p = new Peer(c, id);
                        peers.put(id, p);
                        emit(myGen, "client_in", id, null);
                        readLoop(myGen, p, true);
                    } catch (IOException e) {
                        if (gen != myGen) return;
                        try { Thread.sleep(200); } catch (InterruptedException ignored) { }
                    }
                }
            }
        }, "net-accept").start();
    }

    private void readLoop(final int myGen, final Peer p, final boolean isHostSide) {
        new Thread(new Runnable() {
            public void run() {
                try {
                    BufferedReader r = new BufferedReader(new InputStreamReader(p.socket.getInputStream(), UTF8));
                    String line;
                    while (gen == myGen && (line = r.readLine()) != null) {
                        if (line.length() > 0) emit(myGen, "msg", p.id, line);
                    }
                } catch (IOException ignored) {
                }
                boolean wasOpen = !p.closed;
                p.close();
                if (isHostSide) {
                    peers.remove(p.id);
                    if (wasOpen) emit(myGen, "client_out", p.id, null);
                } else {
                    if (hostPeer == p) hostPeer = null;
                    emit(myGen, "disconnected", 0, null);
                }
            }
        }, "net-read-" + p.id).start();
    }

    /* ---------------------------------------------------------------- guest */
    void connect(final int port) {
        stopAll();
        final int myGen = ++gen;
        new Thread(new Runnable() {
            public void run() {
                bindToWifi();
                long end = System.currentTimeMillis() + 40000;
                Socket s = null;
                while (gen == myGen && s == null && System.currentTimeMillis() < end) {
                    for (String ip : candidateHosts()) {
                        if (gen != myGen) return;
                        try {
                            Socket t = new Socket();
                            t.connect(new InetSocketAddress(ip, port), 2000);
                            s = t;
                            break;
                        } catch (IOException ignored) { }
                    }
                    if (s == null) {
                        try { Thread.sleep(1000); } catch (InterruptedException ignored) { }
                    }
                }
                if (gen != myGen) { if (s != null) try { s.close(); } catch (IOException ignored) { } return; }
                if (s == null) { emit(myGen, "error", 0, "timeout"); return; }
                try { s.setTcpNoDelay(true); s.setKeepAlive(true); } catch (IOException ignored) { }
                Peer p = new Peer(s, 0);
                hostPeer = p;
                emit(myGen, "connected", 0, null);
                readLoop(myGen, p, false);
            }
        }, "net-connect").start();
    }

    private List<String> candidateHosts() {
        List<String> out = new ArrayList<String>();
        try {
            WifiManager wm = (WifiManager) ctx.getSystemService(Context.WIFI_SERVICE);
            if (wm != null) {
                DhcpInfo d = wm.getDhcpInfo();
                if (d != null && d.gateway != 0) {
                    int g = d.gateway;   // little-endian
                    out.add((g & 0xff) + "." + ((g >> 8) & 0xff) + "." + ((g >> 16) & 0xff) + "." + ((g >> 24) & 0xff));
                }
            }
        } catch (Exception ignored) { }
        for (String f : FALLBACK_HOSTS) if (!out.contains(f)) out.add(f);
        return out;
    }

    // keep our sockets on the Wi-Fi even if the hotspot has no internet and phone data is on
    private void bindToWifi() {
        if (Build.VERSION.SDK_INT < 23) return;
        try {
            ConnectivityManager cm = (ConnectivityManager) ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return;
            for (Network n : cm.getAllNetworks()) {
                NetworkCapabilities nc = cm.getNetworkCapabilities(n);
                if (nc != null && nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                    cm.bindProcessToNetwork(n);
                    return;
                }
            }
        } catch (Exception ignored) { }
    }

    private void unbindWifi() {
        if (Build.VERSION.SDK_INT < 23) return;
        try {
            ConnectivityManager cm = (ConnectivityManager) ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm != null) cm.bindProcessToNetwork(null);
        } catch (Exception ignored) { }
    }

    /* ----------------------------------------------------------------- send */
    void sendTo(int id, String msg) { Peer p = peers.get(id); if (p != null) p.send(msg); }
    void sendAll(String msg) { for (Peer p : peers.values()) p.send(msg); }
    void sendToHost(String msg) { Peer p = hostPeer; if (p != null) p.send(msg); }
    void drop(int id) { Peer p = peers.remove(id); if (p != null) p.close(); }

    void stopAll() {
        gen++;
        try { if (server != null) server.close(); } catch (IOException ignored) { }
        server = null;
        for (Peer p : peers.values()) p.close();
        peers.clear();
        Peer h = hostPeer;
        hostPeer = null;
        if (h != null) h.close();
        unbindWifi();
    }

    private void emit(int myGen, String kind, int id, String data) {
        if (gen == myGen) listener.onEvent(kind, id, data);
    }
}
